-- Para bases de datos ya creadas: amplía el campo porque muchas URLs de imágenes superan 255 caracteres
ALTER TABLE productos MODIFY imagen_url VARCHAR(2048) NULL;
