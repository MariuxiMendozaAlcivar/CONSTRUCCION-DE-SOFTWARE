-- Crea la base de datos de SIGPER con soporte para emojis y caracteres especiales en español, y la selecciona
CREATE DATABASE IF NOT EXISTS sigper CHARACTER SET utf8mb4;
USE sigper;

-- Tabla de personas que usan el sistema (administradores, meseros o cocina) y su estado activo/inactivo
CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(120) UNIQUE,
  password_hash VARCHAR(100) NOT NULL,
  rol ENUM('ADMIN','MESERO','COCINA') NOT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1
);

-- Tabla de categorías del menú (por ejemplo, bebidas, entradas o platos fuertes)
CREATE TABLE categorias (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL UNIQUE,
  descripcion VARCHAR(255),
  activo TINYINT(1) NOT NULL DEFAULT 1
);

-- Tabla de platos o productos del menú, vinculados a una categoría y con precio mayor a cero
CREATE TABLE productos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(20) NOT NULL UNIQUE,
  nombre VARCHAR(100) NOT NULL,
  descripcion VARCHAR(255),
  precio DECIMAL(10,2) NOT NULL CHECK (precio > 0),
  categoria_id INT NOT NULL,
  imagen_url VARCHAR(2048),
  activo TINYINT(1) NOT NULL DEFAULT 1,
  FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);

-- Tabla principal de pedidos: guarda quién lo registró, si es mesa o para llevar, estado actual y total
CREATE TABLE pedidos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  usuario_id INT NOT NULL,
  tipo ENUM('MESA','LLEVAR') NOT NULL,
  mesa VARCHAR(10),
  estado ENUM('Pendiente','En preparación','Listo','Entregado','Cancelado') NOT NULL DEFAULT 'Pendiente',
  total DECIMAL(10,2) NOT NULL DEFAULT 0,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Detalle de cada pedido: qué productos se pidieron, cuántas unidades, precio al momento y notas especiales
CREATE TABLE pedido_detalle (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pedido_id INT NOT NULL,
  producto_id INT NOT NULL,
  cantidad INT NOT NULL CHECK (cantidad > 0),
  precio_unitario DECIMAL(10,2) NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  observaciones VARCHAR(255),
  FOREIGN KEY (pedido_id) REFERENCES pedidos(id) ON DELETE CASCADE,
  FOREIGN KEY (producto_id) REFERENCES productos(id)
);

-- Bitácora de cambios de estado de cada pedido para saber qué pasó, quién lo hizo y a qué hora
CREATE TABLE historial_estados (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pedido_id INT NOT NULL,
  estado_anterior VARCHAR(20),
  estado_nuevo VARCHAR(20) NOT NULL,
  usuario_id INT NOT NULL,
  fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
