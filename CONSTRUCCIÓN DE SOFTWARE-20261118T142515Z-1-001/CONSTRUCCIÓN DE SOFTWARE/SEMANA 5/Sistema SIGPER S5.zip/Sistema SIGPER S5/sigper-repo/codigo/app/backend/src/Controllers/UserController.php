<?php
namespace Sigper\Controllers;

use Sigper\Core\Request;
use Sigper\Core\Response;
use Sigper\Core\Validator;
use Sigper\Exceptions\NotFoundException;
use Sigper\Repositories\UserRepository;
use Sigper\Security\PasswordHasher;

final class UserController
{
    // Roles válidos que puede tener un usuario en el sistema
    private const ROLES = ['ADMIN', 'MESERO', 'COCINA'];

    // Guarda el acceso a usuarios en la base de datos y la herramienta para proteger contraseñas
    public function __construct(private UserRepository $users, private PasswordHasher $hasher)
    {
    }

    public function index(Request $r): Response
    {
        // Devuelve la lista de todos los usuarios registrados
        return Response::json($this->users->all());
    }

    public function store(Request $r): Response
    {
        $d = $r->body;
        // Revisa campos obligatorios, que el rol sea válido y que la clave tenga mínimo 8 letras/números
        Validator::required($d, ['nombre', 'username', 'password', 'rol']);
        Validator::assert(in_array($d['rol'], self::ROLES, true), 'Rol inválido');
        Validator::assert(strlen((string) $d['password']) >= 8, 'La contraseña debe tener al menos 8 caracteres');
        // Guarda el usuario encriptando su contraseña para que no quede visible en la base de datos
        $id = $this->users->create($d, $this->hasher->hash((string) $d['password']));
        return Response::json(['id' => $id], 201);
    }

    public function update(Request $r, array $p): Response
    {
        $d = $r->body;
        $id = (int) $p['id'];
        // El administrador solo puede editar nombre, usuario y rol (cualquier otro dato enviado se ignora)
        Validator::required($d, ['nombre', 'username', 'rol']);
        Validator::assert(in_array($d['rol'], self::ROLES, true), 'Rol inválido');
        $actual = $this->users->findById($id);
        if ($actual === null) {
            throw new NotFoundException('Usuario no encontrado');
        }
        // Evita que el administrador se quite a sí mismo el rol y se quede sin acceso
        Validator::assert($id !== (int) $r->user['id'] || $d['rol'] === $actual['rol'], 'No puede cambiar su propio rol');
        $this->users->update($id, $d);
        return Response::json(['ok' => true]);
    }

    public function destroy(Request $r, array $p): Response
    {
        // Evita que alguien elimine su propia cuenta
        Validator::assert((int) $p['id'] !== (int) $r->user['id'], 'No puede eliminar su propia cuenta');
        if (!$this->users->delete((int) $p['id'])) {
            throw new NotFoundException('Usuario no encontrado');
        }
        return Response::json(['ok' => true]);
    }

    public function changePassword(Request $r, array $p): Response
    {
        // Solo el administrador llega aquí (lo exige la ruta): valida la nueva contraseña y la guarda cifrada
        $pass = (string) ($r->body['password'] ?? '');
        Validator::assert(strlen($pass) >= 8, 'La contraseña debe tener al menos 8 caracteres');
        if (!$this->users->setPassword((int) $p['id'], $this->hasher->hash($pass))) {
            throw new NotFoundException('Usuario no encontrado');
        }
        return Response::json(['ok' => true]);
    }

    public function setActive(Request $r, array $p): Response
    {
        // Evita que alguien se desactive a sí mismo por accidente
        Validator::assert((int) $p['id'] !== (int) $r->user['id'], 'No puede desactivar su propia cuenta');
        // Activa o desactiva la cuenta del usuario elegido
        $this->users->setActive((int) $p['id'], !empty($r->body['activo']));
        return Response::json(['ok' => true]);
    }
}