import { useEffect, useState } from 'react';
import { api } from '../api.js';

// Valores iniciales limpios para registrar un nuevo usuario con rol de mesero por defecto
const vacio = { nombre: '', username: '', email: '', password: '', rol: 'MESERO' };

// Pantalla de administración para crear cuentas de personal, asignar roles y editar o eliminar usuarios
export default function Users() {
  // Lista de usuarios registrados, datos del formulario y mensaje de error si ocurre un fallo
  const [list, setList] = useState([]);
  const [f, setF] = useState(vacio);
  const [editId, setEditId] = useState(null); // id del usuario que se está editando (null = registrando uno nuevo)
  const [msg, setMsg] = useState('');
  const [pw, setPw] = useState(null); // usuario al que se le está cambiando la contraseña
  const [nuevaPass, setNuevaPass] = useState('');
  const [ok, setOk] = useState('');

  // Consulta al servidor la lista actualizada de usuarios
  const cargar = () => api('/usuarios').then(setList);

  // Carga los usuarios al abrir la pantalla
  useEffect(() => { cargar(); }, []);

  // Crea un usuario nuevo o, si se está editando, guarda solo nombre, usuario y rol
  const guardar = async (e) => {
    e.preventDefault();
    try {
      if (editId) {
        await api(`/usuarios/${editId}`, { method: 'PUT', body: { nombre: f.nombre, username: f.username, rol: f.rol } });
      } else {
        await api('/usuarios', { method: 'POST', body: f });
      }
      cancelar(); cargar();
    } catch (err) { setMsg(err.message); }
  };

  // Carga los datos del usuario en el formulario para editarlos
  const editar = (u) => { setEditId(u.id); setF({ ...vacio, nombre: u.nombre, username: u.username, rol: u.rol }); setMsg(''); };

  // Guarda la nueva contraseña de un usuario (solo el administrador puede hacerlo)
  const cambiarPass = async (e) => {
    e.preventDefault();
    try {
      await api(`/usuarios/${pw.id}/password`, { method: 'PATCH', body: { password: nuevaPass } });
      setOk(`Contraseña de "${pw.nombre}" actualizada`); setPw(null); setNuevaPass(''); setMsg(''); cargar();
    } catch (err) { setMsg(err.message); setOk(''); }
  };

  // Sale del modo edición y limpia el formulario
  const cancelar = () => { setEditId(null); setF(vacio); setMsg(''); };

  // Elimina un usuario previa confirmación
  const eliminar = async (u) => {
    if (!window.confirm(`¿Eliminar al usuario "${u.nombre}"? Esta acción no se puede deshacer.`)) return;
    try { await api(`/usuarios/${u.id}`, { method: 'DELETE' }); if (editId === u.id) cancelar(); else setMsg(''); cargar(); }
    catch (err) { setMsg(err.message); }
  };

  // Alterna el estado activo/inactivo de un usuario para habilitar o bloquear su acceso
  const toggle = async (u) => {
    try { await api(`/usuarios/${u.id}/activo`, { method: 'PATCH', body: { activo: !u.activo } }); cargar(); }
    catch (err) { setMsg(err.message); }
  };

  // Actualiza un campo concreto del formulario
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  return (
    <>
      {/* Encabezado con el título de la sección y el total de usuarios */}
      <div className="d-flex align-items-center justify-content-between mb-3">
        <h4 className="mb-0 fw-bold">Gestión de usuarios</h4>
        <span className="text-muted small">{list.length} registrados</span>
      </div>

      {/* Aviso rojo si ocurre algún error al crear o cambiar el estado de un usuario */}
      {msg && <div className="alert alert-danger py-2">{msg}</div>}
      {ok && <div className="alert alert-success py-2">{ok}</div>}

      {/* Formulario para registrar un usuario nuevo o editar nombre, usuario y rol de uno existente */}
      <div className="card p-3 mb-4">
        {editId && <div className="small text-muted mb-2">Editando usuario (solo nombre, usuario y rol)</div>}
        <form onSubmit={guardar} className="row g-2 align-items-center">
          <div className="col-md"><input className="form-control" placeholder="Nombre completo" required value={f.nombre} onChange={set('nombre')} /></div>
          <div className="col-md"><input className="form-control" placeholder="Usuario" required value={f.username} onChange={set('username')} /></div>
          {!editId && <div className="col-md"><input className="form-control" type="email" placeholder="Correo" value={f.email} onChange={set('email')} /></div>}
          {!editId && <div className="col-md"><input className="form-control" type="password" placeholder="Contraseña" required value={f.password} onChange={set('password')} /></div>}
          <div className="col-md">
            <select className="form-select" value={f.rol} onChange={set('rol')}>
              <option value="ADMIN">Administrador</option><option value="MESERO">Mesero</option><option value="COCINA">Cocina</option>
            </select>
          </div>
          <div className="col-auto d-flex align-items-center gap-1">
            <button className="btn btn-primary px-3">{editId ? 'Actualizar' : 'Registrar'}</button>
            {editId && <button type="button" className="btn btn-outline-secondary btn-sm" onClick={cancelar}>Cancelar</button>}
          </div>
        </form>
      </div>

      {/* Formulario para asignar una nueva contraseña al usuario elegido */}
      {pw && (
        <div className="card p-3 mb-4">
          <div className="small text-muted mb-2">Nueva contraseña para <strong>{pw.nombre}</strong> ({pw.username})</div>
          <form onSubmit={cambiarPass} className="row g-2 align-items-center">
            <div className="col-md-4">
              <input className="form-control" type="password" placeholder="Nueva contraseña (mín. 8 caracteres)" required minLength={8}
                value={nuevaPass} onChange={(e) => setNuevaPass(e.target.value)} />
            </div>
            <div className="col-auto d-flex align-items-center gap-1">
              <button className="btn btn-primary px-3">Guardar contraseña</button>
              <button type="button" className="btn btn-outline-secondary btn-sm" onClick={() => { setPw(null); setNuevaPass(''); }}>Cancelar</button>
            </div>
          </form>
        </div>
      )}

      {/* Tabla de usuarios registrados con su rol, estado y botón para activar o desactivar */}
      <div className="table-responsive">
        <table className="table table-hover align-middle">
          <thead><tr><th>Nombre</th><th>Usuario</th><th>Correo</th><th>Rol</th><th>Estado</th><th className="text-end">Acción</th></tr></thead>
          <tbody>
            {list.map((u) => (
              <tr key={u.id}>
                <td className="fw-semibold">{u.nombre}</td>
                <td><code>{u.username}</code></td>
                <td>{u.email}</td>
                <td><span className="badge text-bg-light border text-dark">{u.rol}</span></td>
                <td>
                  <span className={`badge ${u.activo ? 'text-bg-success' : 'text-bg-secondary'}`}>
                    {u.activo ? 'Activo' : 'Inactivo'}
                  </span>
                </td>
                <td className="text-end text-nowrap">
                  <button className="btn btn-sm btn-outline-primary me-1" onClick={() => editar(u)}>Editar</button>
                  <button className="btn btn-sm btn-outline-dark me-1" onClick={() => { setPw(u); setNuevaPass(''); setMsg(''); setOk(''); }}>Contraseña</button>
                  {!u.activo && <button className="btn btn-sm btn-outline-secondary me-1" onClick={() => toggle(u)}>Activar</button>}
                  <button className="btn btn-sm btn-outline-danger" onClick={() => eliminar(u)}>Eliminar</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
