<?php
namespace Sigper\Repositories;

use PDOException;
use Sigper\Core\Database;
use Sigper\Exceptions\ConflictException;

final class UserRepository
{
    // Guarda la conexión a la base de datos para consultar o gestionar usuarios
    public function __construct(private Database $db)
    {
    }

    public function all(): array
    {
        // Lista los usuarios ordenados por id sin traer la contraseña cifrada
        return $this->db->pdo()->query('SELECT id,nombre,username,email,rol,activo FROM usuarios ORDER BY id')->fetchAll();
    }

    public function findByIdentifier(string $identifier): ?array
    {
        // Busca un usuario por su nombre de usuario o por su correo (útil al iniciar sesión)
        $st = $this->db->pdo()->prepare('SELECT * FROM usuarios WHERE username=? OR email=?');
        $st->execute([$identifier, $identifier]);
        return $st->fetch() ?: null;
    }

    public function create(array $u, string $passwordHash): int
    {
        // Registra un usuario nuevo con su contraseña ya protegida y devuelve su id; avisa si ya existe
        try {
            $st = $this->db->pdo()->prepare('INSERT INTO usuarios (nombre,username,email,password_hash,rol) VALUES (?,?,?,?,?)');
            $st->execute([$u['nombre'], $u['username'], ($u['email'] ?? '') ?: null, $passwordHash, $u['rol']]);
            return (int) $this->db->pdo()->lastInsertId();
        } catch (PDOException $e) {
            throw $this->duplicate($e);
        }
    }

    public function update(int $id, array $u): void
    {
        // Actualiza solo nombre, usuario y rol (el correo y la contraseña no se modifican desde aquí); avisa si el usuario ya existe
        try {
            $this->db->pdo()->prepare('UPDATE usuarios SET nombre=?, username=?, rol=? WHERE id=?')
                ->execute([trim($u['nombre']), trim($u['username']), $u['rol'], $id]);
        } catch (PDOException $e) {
            throw $this->duplicate($e);
        }
    }

    public function delete(int $id): bool
    {
        // Elimina al usuario; si ya registró pedidos o cambios de estado, la base de datos lo impide y se avisa con un mensaje claro
        try {
            $st = $this->db->pdo()->prepare('DELETE FROM usuarios WHERE id=?');
            $st->execute([$id]);
            return $st->rowCount() > 0;
        } catch (PDOException $e) {
            throw $e->getCode() === '23000'
                ? new ConflictException('No se puede eliminar: el usuario tiene pedidos registrados. Puede desactivarlo en su lugar.')
                : $e;
        }
    }

    public function findById(int $id): ?array
    {
        // Busca un usuario por su id sin traer la contraseña cifrada
        $st = $this->db->pdo()->prepare('SELECT id,nombre,username,email,rol,activo FROM usuarios WHERE id=?');
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }

    public function setActive(int $id, bool $active): void
    {
        // Activa o desactiva la cuenta de un usuario sin borrar su historial
        $this->db->pdo()->prepare('UPDATE usuarios SET activo=? WHERE id=?')->execute([$active ? 1 : 0, $id]);
    }

    public function setPassword(int $id, string $passwordHash): bool
    {
        // Guarda la nueva contraseña cifrada del usuario; devuelve false si el usuario no existe
        $st = $this->db->pdo()->prepare('UPDATE usuarios SET password_hash=? WHERE id=?');
        $st->execute([$passwordHash, $id]);
        return $this->findById($id) !== null;
    }

    private function duplicate(PDOException $e): \Throwable
    {
        // Si la base de datos marca duplicado (código 23000), lanza un error claro de conflicto
        return $e->getCode() === '23000' ? new ConflictException('Usuario o correo ya existe') : $e;
    }
}
