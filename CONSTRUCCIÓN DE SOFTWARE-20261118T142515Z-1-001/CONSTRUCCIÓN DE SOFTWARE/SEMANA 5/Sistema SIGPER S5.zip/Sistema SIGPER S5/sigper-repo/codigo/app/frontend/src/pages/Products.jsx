import { useEffect, useState } from 'react';
import { api } from '../api.js';

// Valores iniciales limpios para el formulario de crear o editar un producto
const vacio = { id: null, codigo: '', nombre: '', descripcion: '', precio: '', categoria_id: '', imagen_url: '', activo: 1 };

// Miniatura del producto: si no hay URL o la imagen no carga, muestra un recuadro con 🍽️
function Miniatura({ url, nombre, size = 48 }) {
  const [error, setError] = useState(false);
  useEffect(() => setError(false), [url]);
  const caja = { width: size, height: size, borderRadius: 8, flexShrink: 0 };
  if (!url || error) {
    return <div className="d-flex align-items-center justify-content-center bg-light border text-muted" style={caja}>🍽️</div>;
  }
  return (
    <img src={url} alt={nombre} style={{ ...caja, objectFit: 'cover' }}
      referrerPolicy="no-referrer" loading="lazy" onError={() => setError(true)} />
  );
}

// Pantalla para administrar los productos del menú (crear, editar precios o datos y activar/desactivar disponibilidad)
export default function Products() {
  // Lista de productos, categorías activas para elegir, datos del formulario y mensaje de error
  const [list, setList] = useState([]);
  const [cats, setCats] = useState([]);
  const [f, setF] = useState(vacio);
  const [msg, setMsg] = useState('');

  // Consulta todos los productos registrados al servidor
  const cargar = () => api('/productos').then(setList);

  // Carga productos y categorías activas al abrir la pantalla
  useEffect(() => { cargar(); api('/categorias?activas=1').then(setCats); }, []);

  // Actualiza un campo concreto del formulario
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  // Guarda un producto nuevo o actualiza uno existente, y limpia el formulario al terminar
  const guardar = async (e) => {
    e.preventDefault();
    try {
      await api(f.id ? `/productos/${f.id}` : '/productos', { method: f.id ? 'PUT' : 'POST', body: f });
      setF(vacio); setMsg(''); cargar();
    } catch (err) { setMsg(err.message); }
  };

  // Cambia si un producto está disponible o no disponible en el menú
  const toggle = async (p) => { await api(`/productos/${p.id}`, { method: 'PUT', body: { ...p, activo: !p.activo } }); cargar(); };

  return (
    <>
      {/* Encabezado con el título de la sección y el total de productos */}
      <div className="d-flex align-items-center justify-content-between mb-3">
        <h4 className="mb-0 fw-bold">Productos del menú</h4>
        <span className="text-muted small">{list.length} productos</span>
      </div>

      {/* Aviso rojo si ocurre algún error al guardar */}
      {msg && <div className="alert alert-danger py-2">{msg}</div>}

      {/* Formulario para agregar un producto o modificar uno ya existente */}
      <div className="card p-3 mb-4">
        <form onSubmit={guardar} className="row g-2 align-items-center">
          <div className="col-sm-4 col-md-2 col-lg-1">
            <input className="form-control" placeholder="Código" required value={f.codigo} onChange={set('codigo')} />
          </div>
          <div className="col-sm-8 col-md-4 col-lg-2">
            <input className="form-control" placeholder="Nombre" required value={f.nombre} onChange={set('nombre')} />
          </div>
          <div className="col-sm-12 col-md-6 col-lg-3">
            <input className="form-control" placeholder="Descripción" value={f.descripcion} onChange={set('descripcion')} />
          </div>
          <div className="col-sm-4 col-md-3 col-lg-1">
            <input className="form-control" type="number" step="0.01" min="0.01" placeholder="Precio" required value={f.precio} onChange={set('precio')} />
          </div>
          <div className="col-sm-8 col-md-4 col-lg-2">
            <select className="form-select" required value={f.categoria_id} onChange={set('categoria_id')}>
              <option value="">Categoría...</option>
              {cats.map((c) => <option key={c.id} value={c.id}>{c.nombre}</option>)}
            </select>
          </div>
          <div className="col-sm-12 col-md-5 col-lg-2">
            <input className="form-control" type="url" placeholder="URL imagen (opcional)" value={f.imagen_url || ''} onChange={set('imagen_url')} />
          </div>
          {/* Vista previa de la imagen mientras se escribe/pega la URL */}
          {f.imagen_url && (
            <div className="col-auto"><Miniatura url={f.imagen_url} nombre="Vista previa" size={56} /></div>
          )}
          <div className="col-auto d-flex align-items-center gap-1">
            <button className="btn btn-primary px-3">{f.id ? 'Actualizar' : 'Agregar'}</button>
            {f.id && (
              <button type="button" className="btn btn-outline-secondary btn-sm" onClick={() => setF(vacio)}>
                Cancelar
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Tabla con todos los productos, categoría, precio, disponibilidad y acciones */}
      <div className="table-responsive">
        <table className="table table-hover align-middle">
          <thead>
            <tr>
              <th>Imagen</th>
              <th>Código</th>
              <th>Nombre</th>
              <th>Categoría</th>
              <th>Precio</th>
              <th>Estado</th>
              <th className="text-end">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {list.map((p) => (
              <tr key={p.id}>
                <td><Miniatura url={p.imagen_url} nombre={p.nombre} /></td>
                <td><code>{p.codigo}</code></td>
                <td>
                  <div className="fw-semibold">{p.nombre}</div>
                  {p.descripcion && <div className="text-muted small">{p.descripcion}</div>}
                </td>
                <td><span className="badge text-bg-light border text-dark">{p.categoria}</span></td>
                <td className="fw-semibold">${Number(p.precio).toFixed(2)}</td>
                <td>
                  <span className={`badge ${p.activo ? 'text-bg-success' : 'text-bg-secondary'}`}>
                    {p.activo ? 'Disponible' : 'No disponible'}
                  </span>
                </td>
                <td className="text-end text-nowrap">
                  <button className="btn btn-sm btn-outline-primary me-1" onClick={() => setF({ ...p })}>Editar</button>
                  <button className="btn btn-sm btn-outline-secondary" onClick={() => toggle(p)}>
                    {p.activo ? 'Desactivar' : 'Activar'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}