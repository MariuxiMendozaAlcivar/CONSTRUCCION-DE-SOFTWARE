import { useEffect, useState } from 'react';
import { api } from '../api.js';

// Valores iniciales limpios para el formulario de crear o editar una categoría
const vacio = { id: null, nombre: '', descripcion: '', activo: 1 };

// Pantalla para administrar las categorías del menú (verlas, crear, editar y activar o desactivar)
export default function Categories() {
  // Lista de categorías cargadas, datos del formulario nuevo y mensaje de error si algo falla
  const [list, setList] = useState([]);
  const [f, setF] = useState(vacio);
  const [msg, setMsg] = useState('');

  // Pide al servidor la lista actualizada de categorías
  const cargar = () => api('/categorias').then(setList);

  // Carga las categorías apenas se abre la pantalla
  useEffect(() => { cargar(); }, []);

  // Crea una categoría nueva o guarda los cambios de una existente, y limpia el formulario si todo sale bien
  const guardar = async (e) => {
    e.preventDefault();
    try {
      await api(f.id ? `/categorias/${f.id}` : '/categorias', { method: f.id ? 'PUT' : 'POST', body: f });
      setF(vacio); setMsg(''); cargar();
    } catch (err) { setMsg(err.message); }
  };

  // Cambia una categoría entre activa e inactiva y refresca la tabla
  const toggle = async (c) => {
    await api(`/categorias/${c.id}`, { method: 'PUT', body: { ...c, activo: !c.activo } });
    cargar();
  };

  return (
    <>
      {/* Encabezado con el título de la sección y el total de categorías */}
      <div className="d-flex align-items-center justify-content-between mb-3">
        <h4 className="mb-0 fw-bold">Categorías del menú</h4>
        <span className="text-muted small">{list.length} categorías</span>
      </div>

      {/* Muestra un aviso rojo si ocurrió un error al guardar */}
      {msg && <div className="alert alert-danger py-2">{msg}</div>}

      {/* Formulario para agregar una nueva categoría */}
      <div className="card p-3 mb-4">
        <form onSubmit={guardar} className="row g-2 align-items-center">
          <div className="col-md-3">
            <input className="form-control" placeholder="Nombre" required value={f.nombre} onChange={(e) => setF({ ...f, nombre: e.target.value })} />
          </div>
          <div className="col-md-6">
            <input className="form-control" placeholder="Descripción (opcional)" value={f.descripcion || ''} onChange={(e) => setF({ ...f, descripcion: e.target.value })} />
          </div>
          <div className="col-auto d-flex align-items-center gap-1">
            <button className="btn btn-primary px-3">{f.id ? 'Actualizar' : 'Agregar'}</button>
            {f.id && (
              <button type="button" className="btn btn-outline-secondary btn-sm" onClick={() => { setF(vacio); setMsg(''); }}>
                Cancelar
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Tabla con las categorías registradas y botón rápido para activar o desactivar */}
      <div className="table-responsive">
        <table className="table table-hover align-middle">
          <thead>
            <tr><th>Nombre</th><th>Descripción</th><th>Estado</th><th className="text-end">Acción</th></tr>
          </thead>
          <tbody>
            {list.map((c) => (
              <tr key={c.id}>
                <td className="fw-semibold">{c.nombre}</td>
                <td className="text-muted">{c.descripcion || '—'}</td>
                <td>
                  <span className={`badge ${c.activo ? 'text-bg-success' : 'text-bg-secondary'}`}>
                    {c.activo ? 'Activa' : 'Inactiva'}
                  </span>
                </td>
                <td className="text-end text-nowrap">
                  <button className="btn btn-sm btn-outline-primary me-1" onClick={() => { setF({ ...c }); setMsg(''); }}>Editar</button>
                  <button className="btn btn-sm btn-outline-secondary" onClick={() => toggle(c)}>
                    {c.activo ? 'Desactivar' : 'Activar'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}