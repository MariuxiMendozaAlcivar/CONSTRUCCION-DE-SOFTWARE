# Documentación

Coloque aquí (según lo solicitado en el proyecto):

- Documento de Diseño Detallado de Software (corregido y actualizado)
- Documento de alcance y documento de requerimientos
- Diagramas UML: casos de uso, clases, secuencia, entidad-relación, despliegue
- Ingeniería de requerimientos (6): casos de uso, análisis, diseño, despliegue, implementación, pruebas
- Plan de pruebas (plantilla del curso) y modelo de pruebas / modelo de implementación
- Manual de usuario
- Manual de soporte (instrucciones paso a paso para desplegar en otro servidor)
- Bitácora de actividades y reuniones
- Artículo científico y artículo de experiencias pasadas
