# SIGPER – Sistema web de gestión de pedidos para restaurantes

| Carpeta | Contenido |
|---|---|
| `codigo/sql` | Scripts SQL (esquema y datos de prueba) |
| `codigo/app/backend` | API en **PHP puro** (PDO, sin framework) + pruebas PHPUnit |
| `codigo/app/frontend` | React + Vite + Bootstrap (publicable en GitHub Pages) |
| `documentacion` | Documentos del proyecto |

## Ejecución local
1. MySQL: ejecutar `codigo/sql/01_schema.sql` y luego `02_datos_prueba.sql`.
2. Backend (PHP ≥ 8.1 con extensión pdo_mysql):
   ```
   cd codigo/app/backend
   copy .env.example .env      (editar credenciales y JWT_SECRET)
   php bin/seed.php
   php -S 0.0.0.0:4000 -t public public/index.php
   ```
3. Frontend:
   ```
   cd codigo/app/frontend
   npm install
   npm run dev                 -> http://localhost:5173
   ```

## Pruebas unitarias (PHPUnit)
```
cd codigo/app/backend
composer install
vendor\bin\phpunit
```

## Despliegue
- **Frontend en GitHub Pages:** crear `.env` con `VITE_API_URL=https://su-backend` y ejecutar `npm run deploy`
  (publica `dist` en la rama `gh-pages`; activar Pages sobre esa rama).
- **Backend:** GitHub Pages solo sirve archivos estáticos, el PHP debe alojarse en un servidor con PHP y MySQL
  (hosting compartido, VPS, etc.) con HTTPS. Subir `codigo/app/backend`, apuntar el dominio a `public/`,
  crear `.env` y ejecutar el SQL. Ajustar `CORS_ORIGIN` al dominio de GitHub Pages.
