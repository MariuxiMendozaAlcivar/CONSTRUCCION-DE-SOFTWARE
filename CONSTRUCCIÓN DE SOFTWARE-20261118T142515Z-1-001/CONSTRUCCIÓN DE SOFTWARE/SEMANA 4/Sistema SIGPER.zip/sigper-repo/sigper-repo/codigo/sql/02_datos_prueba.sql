-- Selecciona la base de datos de SIGPER para cargar los datos iniciales
USE sigper;

-- Los usuarios iniciales (admin / mesero / cocina) se crean con:  php bin/seed.php
-- porque PHP genera el hash de la contraseña (password_hash / bcrypt).

-- Inserta las categorías base del menú para organizar los productos
INSERT INTO categorias (nombre, descripcion) VALUES
  ('Bebidas', 'Jugos y gaseosas'),
  ('Platos fuertes', 'Almuerzos'),
  ('Postres', 'Dulces');

-- Inserta los productos iniciales del menú con su código, precio y categoría correspondiente
INSERT INTO productos (codigo, nombre, descripcion, precio, categoria_id) VALUES
  ('BEB-01', 'Jugo natural', 'Vaso 12 oz', 2.50, 1),
  ('BEB-02', 'Gaseosa', 'Botella personal', 1.50, 1),
  ('PLA-01', 'Seco de pollo', 'Con arroz y ensalada', 5.00, 2),
  ('PLA-02', 'Encebollado', 'Con pan', 4.00, 2),
  ('POS-01', 'Flan de vainilla', 'Porción individual', 2.00, 3);
