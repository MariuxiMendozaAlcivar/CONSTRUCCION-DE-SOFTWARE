<?php
namespace Sigper\Domain;

use Sigper\Exceptions\ConflictException;
use Sigper\Exceptions\ForbiddenException;

/** RN-11 / RN-12: flujo de estados permitido y qué rol puede aplicar cada cambio. */
final class OrderStateMachine
{
    // Define a qué estados puede pasar un pedido según el estado en que esté ahorita
    private const FLOW = [
        'Pendiente' => ['En preparación', 'Cancelado'],
        'En preparación' => ['Listo', 'Cancelado'],
        'Listo' => ['Entregado', 'Cancelado'],
    ];
    // Define qué tipo de usuario puede poner cada estado nuevo
    private const WHO = [
        'En preparación' => ['COCINA', 'ADMIN'],
        'Listo' => ['COCINA', 'ADMIN'],
        'Entregado' => ['MESERO', 'ADMIN'],
        'Cancelado' => ['MESERO', 'ADMIN'],
    ];

    public function assertTransition(OrderStatus $from, OrderStatus $to, string $role): void
    {
        // Revisa si el cambio de estado está permitido (por ejemplo, no saltar directo de Pendiente a Entregado)
        if (!in_array($to->value, self::FLOW[$from->value] ?? [], true)) {
            throw new ConflictException("No se puede pasar de \"{$from->value}\" a \"{$to->value}\"");
        }
        // Revisa si el rol de quien hace el cambio tiene permiso para poner ese estado
        if (!in_array($role, self::WHO[$to->value], true)) {
            throw new ForbiddenException('Su rol no puede aplicar este estado');
        }
    }
}