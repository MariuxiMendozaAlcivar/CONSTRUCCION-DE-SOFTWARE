<?php
namespace Sigper\Repositories;

// Contrato que define qué métodos debe tener cualquier clase que guarde o lea pedidos
interface OrderRepositoryInterface
{
    // Guarda un pedido nuevo con sus productos y total, y devuelve su id
    public function create(int $userId, string $tipo, ?string $mesa, array $lines, float $total): int;
    // Busca los datos básicos de un pedido por su id
    public function find(int $id): ?array;
    // Trae un pedido con todo su detalle y productos incluidos
    public function details(int $id): ?array;
    // Busca pedidos aplicando filtros (estado, mesa, fecha, etc.)
    public function search(array $filters): array;
    // Cambia los productos y el total de un pedido existente
    public function replaceItems(int $id, array $lines, float $total): void;
    // Cambia el estado de un pedido validando el estado anterior y quién hizo el cambio
    public function updateStatus(int $id, string $from, string $to, int $userId): void;
    // Saca un resumen general de pedidos para reportes o tablero
    public function summary(): array;
}