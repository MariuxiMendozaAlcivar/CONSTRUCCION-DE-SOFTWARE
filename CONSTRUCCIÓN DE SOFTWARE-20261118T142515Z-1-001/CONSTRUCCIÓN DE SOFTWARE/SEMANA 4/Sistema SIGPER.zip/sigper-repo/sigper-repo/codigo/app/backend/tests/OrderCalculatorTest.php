<?php
namespace Sigper\Tests;

use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;
use Sigper\Domain\OrderCalculator;
use Sigper\Exceptions\ValidationException;

// Pruebas automáticas para verificar que el cálculo de precios, subtotales y totales de un pedido sea exacto y rechace datos raros
final class OrderCalculatorTest extends TestCase
{
    // Catálogo de ejemplo con un par de productos y sus precios
    private array $products = [1 => ['id' => 1, 'precio' => '2.50'], 2 => ['id' => 2, 'precio' => '5.00']];

    public function testCalculaSubtotalesYTotal(): void
    {
        // Revisa que sume bien cada línea, calcule el total general y limpie espacios sobrantes en las notas
        $r = (new OrderCalculator())->build([
            ['producto_id' => 1, 'cantidad' => 2],
            ['producto_id' => 2, 'cantidad' => 1, 'observaciones' => ' sin cebolla '],
        ], $this->products);

        $this->assertSame(5.0, $r['lines'][0]['subtotal']);
        $this->assertSame(10.0, $r['total']);
        $this->assertSame('sin cebolla', $r['lines'][1]['observaciones']);
    }

    public function testPedidoSinProductosLanzaExcepcion(): void
    {
        // Comprueba que no permita armar un pedido vacío sin productos
        $this->expectException(ValidationException::class);
        (new OrderCalculator())->build([], $this->products);
    }

    public function testProductoNoDisponibleLanzaExcepcion(): void
    {
        // Verifica que avise error si intentan pedir un producto que no existe o no está disponible
        $this->expectException(ValidationException::class);
        (new OrderCalculator())->build([['producto_id' => 99, 'cantidad' => 1]], $this->products);
    }

    #[DataProvider('cantidadesInvalidas')]
    public function testCantidadesInvalidas(mixed $qty): void
    {
        // Ejecuta la prueba con cada cantidad incorrecta para asegurar que todas sean rechazadas
        $this->expectException(ValidationException::class);
        (new OrderCalculator())->build([['producto_id' => 1, 'cantidad' => $qty]], $this->products);
    }

    public static function cantidadesInvalidas(): array
    {
        // Lista de cantidades que no tienen sentido (cero, negativos, texto, decimales o vacíos)
        return [[0], [-3], ['abc'], [1.5], [null]];
    }
}
