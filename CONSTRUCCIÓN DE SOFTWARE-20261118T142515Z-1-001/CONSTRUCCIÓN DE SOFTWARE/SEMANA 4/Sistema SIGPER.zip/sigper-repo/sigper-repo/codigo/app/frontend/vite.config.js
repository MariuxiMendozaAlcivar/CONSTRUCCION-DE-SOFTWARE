import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' permite publicar el build en GitHub Pages (subruta /<repositorio>/).
export default defineConfig({
  base: './',
  plugins: [react()],
  server: {
    host: true,
    allowedHosts: true,
    port: 5173,
    // En desarrollo, /api se redirige al servidor PHP (php -S ... en el puerto 4000).
    proxy: { '/api': 'http://localhost:4000' },
  },
});
