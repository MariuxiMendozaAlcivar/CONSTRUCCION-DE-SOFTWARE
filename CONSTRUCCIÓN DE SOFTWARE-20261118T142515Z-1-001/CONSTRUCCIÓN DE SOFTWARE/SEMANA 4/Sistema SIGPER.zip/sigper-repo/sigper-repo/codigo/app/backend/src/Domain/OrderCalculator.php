<?php
namespace Sigper\Domain;

use Sigper\Exceptions\ValidationException;

/** RF-15: valida líneas y calcula subtotales/total en centavos (evita errores de coma flotante). */
final class OrderCalculator
{
    /**
- @param array $items    [['producto_id'=>1,'cantidad'=>2,'observaciones'=>'...'], ...]
- @param array $products productos disponibles indexados por id (['id'=>..,'precio'=>..])
- @return array{lines: array, total: float}
     */
    public function build(array $items, array $products): array
    {
        // Si no mandaron ningún producto en el pedido, detiene todo y avisa
        if ($items === []) {
            throw new ValidationException('El pedido debe tener al menos un producto');
        }
        $lines = [];
        // Suma todo en centavos para que no se pierdan decimales raros al sumar precios
        $totalCents = 0;
        foreach ($items as $item) {
            // Revisa que la cantidad sea un número entero mayor que cero
            $qty = $item['cantidad'] ?? null;
            if (!is_numeric($qty) || (int) $qty != $qty || (int) $qty <= 0) {
                throw new ValidationException('Las cantidades deben ser mayores que cero');
            }
            $qty = (int) $qty;
            // Busca el producto en la lista de disponibles; si no existe o no está disponible, da error
            $product = $products[(int) ($item['producto_id'] ?? 0)] ?? null;
            if ($product === null) {
                throw new ValidationException('Producto inexistente o no disponible');
            }
            // Pasa el precio a centavos y acumula el subtotal de este producto
            $unit = (int) round(((float) $product['precio']) * 100);
            $totalCents += $unit * $qty;
            // Guarda las notas o comentarios del cliente si escribió algo
            $note = trim((string) ($item['observaciones'] ?? ''));
            // Arma la línea detallada de este producto y la devuelve de vuelta en dólares
            $lines[] = [
                'producto_id' => (int) $product['id'],
                'cantidad' => $qty,
                'precio_unitario' => $unit / 100.0,
                'subtotal' => ($unit * $qty) / 100.0,
                'observaciones' => $note !== '' ? $note : null,
            ];
        }
        // Devuelve todas las líneas calculadas y el total final del pedido
        return ['lines' => $lines, 'total' => $totalCents / 100.0];
    }
}