import { useEffect, useState } from 'react';
import { api } from '../api.js';

// Pantalla para tomar un pedido nuevo: elige productos del menú, arma el carrito y envía la orden
export default function NewOrder() {
  // Productos disponibles, artículos agregados al carrito, tipo/mesa del pedido y mensaje de confirmación o error
  const [productos, setProductos] = useState([]);
  const [carrito, setCarrito] = useState([]); // {producto, cantidad, observaciones}
  const [tipo, setTipo] = useState('MESA');
  const [mesa, setMesa] = useState('');
  const [msg, setMsg] = useState(null);

  // Carga los productos activos al abrir la vista
  useEffect(() => { api('/productos?disponibles=1').then(setProductos); }, []);

  // Agrega un producto al carrito o suma 1 a su cantidad si ya estaba seleccionado
  const agregar = (p) => setCarrito((c) => {
    const ex = c.find((i) => i.producto.id === p.id);
    return ex ? c.map((i) => (i === ex ? { ...i, cantidad: i.cantidad + 1 } : i)) : [...c, { producto: p, cantidad: 1, observaciones: '' }];
  });

  // Actualiza la cantidad o las notas especiales de un producto dentro del carrito
  const cambiar = (id, campo, valor) => setCarrito((c) => c.map((i) => (i.producto.id === id ? { ...i, [campo]: valor } : i)));

  // Elimina un producto del carrito
  const quitar = (id) => setCarrito((c) => c.filter((i) => i.producto.id !== id));

  // Calcula el monto total sumando precio por cantidad de cada ítem
  const total = carrito.reduce((s, i) => s + i.producto.precio * i.cantidad, 0);

  // Envía el pedido al servidor y limpia el carrito si se registra bien
  const guardar = async () => {
    try {
      const r = await api('/pedidos', {
        method: 'POST',
        body: { tipo, mesa, items: carrito.map((i) => ({ producto_id: i.producto.id, cantidad: i.cantidad, observaciones: i.observaciones })) },
      });
      setMsg({ ok: true, t: `Pedido #${r.id} registrado` }); setCarrito([]); setMesa('');
    } catch (e) { setMsg({ ok: false, t: e.message }); }
  };

  // Agrupa los productos disponibles por categoría para mostrar el menú ordenado
  const porCategoria = productos.reduce((acc, p) => ((acc[p.categoria] ||= []).push(p), acc), {});

  return (
    <div className="row g-4">
      {/* Columna izquierda: menú agrupado por categoría */}
      <div className="col-lg-7">
        <div className="card p-3">
          <h4 className="fw-bold mb-3">Menú</h4>
          {!Object.keys(porCategoria).length && (
            <p className="text-muted mb-0">No hay productos disponibles por el momento.</p>
          )}
          {Object.entries(porCategoria).map(([cat, ps]) => (
            <div key={cat} className="mb-4">
              <h6 className="text-uppercase small fw-bold text-muted border-bottom pb-2 mb-2">{cat}</h6>
              <div className="d-flex flex-wrap gap-2">
                {ps.map((p) => (
                  <button key={p.id} className="btn menu-item-btn text-start" onClick={() => agregar(p)} title={p.descripcion}>
                    <div className="fw-semibold text-dark">{p.nombre}</div>
                    <div className="fw-bold mt-1" style={{ color: 'var(--sigper-primary)' }}>
                      ${Number(p.precio).toFixed(2)}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Columna derecha: resumen del pedido, tipo de entrega y total */}
      <div className="col-lg-5">
        <div className="card p-3">
          <h4 className="fw-bold mb-3">Pedido</h4>
          {msg && <div className={`alert py-2 alert-${msg.ok ? 'success' : 'danger'}`}>{msg.t}</div>}
          {/* Selector de pedido por mesa o para llevar */}
          <div className="d-flex gap-2 mb-3">
            <select className="form-select" value={tipo} onChange={(e) => setTipo(e.target.value)}>
              <option value="MESA">Por mesa</option><option value="LLEVAR">Para llevar</option>
            </select>
            {tipo === 'MESA' && (
              <input className="form-control" placeholder="N.º de mesa" value={mesa} onChange={(e) => setMesa(e.target.value)} />
            )}
          </div>

          {/* Lista de productos seleccionados con cantidad, notas y botón para quitar */}
          {carrito.map((i) => (
            <div key={i.producto.id} className="border rounded-3 p-2 mb-2 bg-light-subtle">
              <div className="d-flex align-items-center gap-2">
                <strong className="flex-grow-1">{i.producto.nombre}</strong>
                <input type="number" min="1" className="form-control form-control-sm" style={{ width: 70 }}
                  value={i.cantidad} onChange={(e) => cambiar(i.producto.id, 'cantidad', Math.max(1, +e.target.value || 1))} />
                <span className="fw-semibold">${(i.producto.precio * i.cantidad).toFixed(2)}</span>
                <button className="btn btn-sm btn-outline-danger" onClick={() => quitar(i.producto.id)}>×</button>
              </div>
              <input className="form-control form-control-sm mt-2" placeholder="Observaciones"
                value={i.observaciones} onChange={(e) => cambiar(i.producto.id, 'observaciones', e.target.value)} />
            </div>
          ))}

          <hr />
          <div className="d-flex justify-content-between align-items-center mb-3">
            <span className="text-muted fw-semibold">Total a pagar</span>
            <h5 className="mb-0 fw-bold">${total.toFixed(2)}</h5>
          </div>
          <button className="btn btn-success w-100 py-2" disabled={!carrito.length} onClick={guardar}>
            Registrar pedido
          </button>
        </div>
      </div>
    </div>
  );
}
