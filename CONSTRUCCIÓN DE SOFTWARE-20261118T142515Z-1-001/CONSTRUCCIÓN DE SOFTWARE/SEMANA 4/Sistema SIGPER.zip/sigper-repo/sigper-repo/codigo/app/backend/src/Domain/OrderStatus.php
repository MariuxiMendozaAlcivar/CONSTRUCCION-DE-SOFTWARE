<?php
namespace Sigper\Domain;

enum OrderStatus: string
{
    // Todos los posibles estados en los que puede estar un pedido
    case Pendiente = 'Pendiente';
    case EnPreparacion = 'En preparación';
    case Listo = 'Listo';
    case Entregado = 'Entregado';
    case Cancelado = 'Cancelado';

    /** RF-09: solo se pueden modificar pedidos que aún no están listos. */
    public function isModifiable(): bool
    {
        // Solo deja editar el pedido si todavía está pendiente o en preparación
        return $this === self::Pendiente || $this === self::EnPreparacion;
    }
}