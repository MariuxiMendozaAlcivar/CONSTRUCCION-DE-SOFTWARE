<?php
namespace Sigper\Tests;

use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;
use Sigper\Domain\OrderStateMachine;
use Sigper\Domain\OrderStatus as S;
use Sigper\Exceptions\ConflictException;
use Sigper\Exceptions\ForbiddenException;

// Pruebas automáticas para verificar las reglas de cambio de estado de un pedido y los permisos según el rol
final class OrderStateMachineTest extends TestCase
{
    #[DataProvider('transicionesValidas')]
    public function testTransicionesValidas(S $from, S $to, string $rol): void
    {
        // Comprueba que cada cambio permitido avance sin lanzar error y cuenta la validación como exitosa
        (new OrderStateMachine())->assertTransition($from, $to, $rol);
        $this->addToAssertionCount(1);
    }

    public static function transicionesValidas(): array
    {
        // Combinaciones válidas de estado inicial, estado siguiente y rol autorizado
        return [
            [S::Pendiente, S::EnPreparacion, 'COCINA'],
            [S::EnPreparacion, S::Listo, 'COCINA'],
            [S::Listo, S::Entregado, 'MESERO'],
            [S::Pendiente, S::Cancelado, 'MESERO'],
            [S::Listo, S::Entregado, 'ADMIN'],
        ];
    }

    #[DataProvider('transicionesProhibidas')]
    public function testTransicionesProhibidas(S $from, S $to, string $rol): void
    {
        // Verifica que los saltos o retrocesos prohibidos en el flujo del pedido sean bloqueados
        $this->expectException(ConflictException::class);
        (new OrderStateMachine())->assertTransition($from, $to, $rol);
    }

    public static function transicionesProhibidas(): array
    {
        // Cambios de estado no permitidos (como devolver un pedido entregado o saltar pasos)
        return [
            [S::Entregado, S::EnPreparacion, 'ADMIN'],   // RN-12
            [S::Pendiente, S::Entregado, 'MESERO'],      // salta estados
            [S::Cancelado, S::Pendiente, 'ADMIN'],
        ];
    }

    public function testRolNoAutorizado(): void
    {
        // Comprueba que un rol sin permiso (por ejemplo, un mesero iniciando cocina) reciba error de acceso prohibido
        $this->expectException(ForbiddenException::class);
        (new OrderStateMachine())->assertTransition(S::Pendiente, S::EnPreparacion, 'MESERO');
    }
}