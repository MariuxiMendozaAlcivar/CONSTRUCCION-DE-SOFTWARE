import { useState } from 'react';
import { api } from '../api.js';

// Pantalla de inicio de sesión para entrar al sistema con usuario o correo y contraseña
export default function Login({ onLogin }) {
  // Guarda lo que escribe el usuario y el mensaje de error si las credenciales fallan
  const [f, setF] = useState({ identificador: '', password: '' });
  const [error, setError] = useState('');

  // Envía las credenciales al servidor y, si son válidas, notifica a la app principal para abrir la sesión
  const enviar = async (e) => {
    e.preventDefault();
    try { onLogin(await api('/auth/login', { method: 'POST', body: f })); }
    catch (err) { setError(err.message); }
  };

  return (
    <div className="container d-flex align-items-center justify-content-center" style={{ minHeight: '100vh', maxWidth: 420 }}>
      <div className="w-100">
        {/* Nombre y descripción corta del sistema */}
        <div className="text-center mb-4">
          <h2 className="fw-bold mb-1" style={{ color: 'var(--sigper-primary)', letterSpacing: '0.05em' }}>SIGPER</h2>
          <p className="text-muted small mb-0">Sistema de gestión de pedidos y cocina</p>
        </div>
        {/* Tarjeta con el formulario de acceso */}
        <form onSubmit={enviar} className="card p-4">
          {/* Aviso rojo si el usuario, correo o contraseña no son correctos */}
          {error && <div className="alert alert-danger py-2">{error}</div>}
          <div className="mb-3">
            <label className="form-label small fw-semibold text-muted">Usuario o correo</label>
            <input className="form-control" placeholder="Ej. admin o mesero" required
              value={f.identificador} onChange={(e) => setF({ ...f, identificador: e.target.value })} />
          </div>
          <div className="mb-3">
            <label className="form-label small fw-semibold text-muted">Contraseña</label>
            <input className="form-control" type="password" placeholder="••••••••" required
              value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
          </div>
          <button className="btn btn-primary w-100 py-2">Iniciar sesión</button>
        </form>
      </div>
    </div>
  );
}