<?php
namespace Sigper\Repositories;

use PDOException;
use Sigper\Core\Database;
use Sigper\Exceptions\ConflictException;

final class UserRepository
{
    // Guarda la conexión a la base de datos para consultar o gestionar usuarios
    public function __construct(private Database $db)
    {
    }

    public function all(): array
    {
        // Lista los usuarios ordenados por id sin traer la contraseña cifrada
        return $this->db->pdo()->query('SELECT id,nombre,username,email,rol,activo FROM usuarios ORDER BY id')->fetchAll();
    }

    public function findByIdentifier(string $identifier): ?array
    {
        // Busca un usuario por su nombre de usuario o por su correo (útil al iniciar sesión)
        $st = $this->db->pdo()->prepare('SELECT * FROM usuarios WHERE username=? OR email=?');
        $st->execute([$identifier, $identifier]);
        return $st->fetch() ?: null;
    }

    public function create(array $u, string $passwordHash): int
    {
        // Registra un usuario nuevo con su contraseña ya protegida y devuelve su id; avisa si ya existe
        try {
            $st = $this->db->pdo()->prepare('INSERT INTO usuarios (nombre,username,email,password_hash,rol) VALUES (?,?,?,?,?)');
            $st->execute([$u['nombre'], $u['username'], ($u['email'] ?? '') ?: null, $passwordHash, $u['rol']]);
            return (int) $this->db->pdo()->lastInsertId();
        } catch (PDOException $e) {
            throw $this->duplicate($e);
        }
    }

    public function update(int $id, array $u, ?string $passwordHash): void
    {
        // Actualiza datos básicos del usuario y, solo si mandaron una contraseña nueva, también la cambia
        try {
            $this->db->pdo()->prepare('UPDATE usuarios SET nombre=?, email=?, rol=? WHERE id=?')
                ->execute([$u['nombre'], ($u['email'] ?? '') ?: null, $u['rol'], $id]);
            if ($passwordHash !== null) {
                $this->db->pdo()->prepare('UPDATE usuarios SET password_hash=? WHERE id=?')->execute([$passwordHash, $id]);
            }
        } catch (PDOException $e) {
            throw $this->duplicate($e);
        }
    }

    public function setActive(int $id, bool $active): void
    {
        // Activa o desactiva la cuenta de un usuario sin borrar su historial
        $this->db->pdo()->prepare('UPDATE usuarios SET activo=? WHERE id=?')->execute([$active ? 1 : 0, $id]);
    }

    private function duplicate(PDOException $e): \Throwable
    {
        // Si la base de datos marca duplicado (código 23000), lanza un error claro de conflicto
        return $e->getCode() === '23000' ? new ConflictException('Usuario o correo ya existe') : $e;
    }
}
