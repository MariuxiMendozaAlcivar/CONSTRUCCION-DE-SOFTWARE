<?php
namespace Sigper\Services;

use Sigper\Exceptions\AuthenticationException;
use Sigper\Exceptions\ForbiddenException;
use Sigper\Repositories\UserRepository;
use Sigper\Security\JwtService;
use Sigper\Security\PasswordHasher;

// Coordina el inicio de sesión: busca al usuario, revisa su contraseña y le entrega su pase de acceso
final class AuthService
{
    // Recibe lo necesario para buscar usuarios, validar contraseñas y generar tokens de sesión
    public function __construct(private UserRepository $users, private PasswordHasher $hasher, private JwtService $jwt)
    {
    }

    public function login(string $identifier, string $password): array
    {
        // Busca por usuario o correo y comprueba que la contraseña coincida
        $u = $this->users->findByIdentifier($identifier);
        if (!$u || !$this->hasher->verify($password, $u['password_hash'])) {
            throw new AuthenticationException('Credenciales incorrectas');
        }
        // Si la cuenta está desactivada, no lo deja entrar aunque sus datos sean correctos
        if (!$u['activo']) {
            throw new ForbiddenException('Usuario inactivo');
        }
        // Prepara los datos básicos del usuario, arma su token y devuelve ambos
        $user = ['id' => (int) $u['id'], 'nombre' => $u['nombre'], 'rol' => $u['rol']];
        return ['token' => $this->jwt->issue($user), 'user' => $user];
    }
}