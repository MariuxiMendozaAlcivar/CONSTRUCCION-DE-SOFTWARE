<?php
namespace Sigper\Core;

use Sigper\Exceptions\AuthenticationException;
use Sigper\Exceptions\ForbiddenException;
use Sigper\Security\JwtService;

/** Autentica el token y verifica el rol (RF-04). Lista vacía = cualquier usuario autenticado. */
final class AuthGuard
{
    // Guarda el lector de tokens para revisar si la sesión es válida
    public function __construct(private JwtService $jwt)
    {
    }

    public function check(Request $request, array $roles): void
    {
        // Toma el token de sesión que manda el usuario; si no viene nada, lo rechaza
        $token = $request->bearer();
        if ($token === '') {
            throw new AuthenticationException();
        }
        // Revisa que el token no sea falso ni haya caducado y guarda los datos del usuario
        $request->user = $this->jwt->verify($token);
        // Si la ruta pide ciertos roles y el usuario no tiene uno de esos, le niega el paso
        if ($roles && !in_array($request->user['rol'] ?? '', $roles, true)) {
            throw new ForbiddenException();
        }
    }
}