<?php
namespace Sigper\Config;

/** Lee variables de configuración desde el archivo .env (o del entorno del servidor). */
final class Env
{
    // Guarda aquí las variables que se leen del archivo .env
    private static array $vars = [];

    public static function load(string $file): void
    {
        // Si no existe el archivo .env, no hace nada y sigue normal
        if (!is_file($file)) {
            return;
        }
        // Recorre el archivo línea por línea ignorando líneas vacías
        foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            $line = trim($line);
            // Salta líneas vacías, comentarios con # o líneas que no tengan "="
            if ($line === '' || $line[0] === '#' || strpos($line, '=') === false) {
                continue;
            }
            // Separa el nombre de la variable y su valor (solo en el primer "=")
            [$k, $v] = explode('=', $line, 2);
            self::$vars[trim($k)] = trim($v);
        }
    }

    public static function get(string $key, ?string $default = null): ?string
    {
        // Busca primero en lo cargado del .env, luego en el servidor y si no, devuelve el valor por defecto
        return self::$vars[$key] ?? (getenv($key) ?: $default);
    }
}