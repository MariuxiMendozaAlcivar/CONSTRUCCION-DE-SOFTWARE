<?php
namespace Sigper\Tests;

use PHPUnit\Framework\TestCase;
use Sigper\Domain\{OrderCalculator, OrderStateMachine};
use Sigper\Exceptions\{ConflictException, ForbiddenException, NotFoundException, ValidationException};
use Sigper\Repositories\{OrderRepositoryInterface, ProductCatalogInterface};
use Sigper\Services\OrderService;

/** Pruebas de OrderService con repositorios falsos en memoria (sin base de datos). */
// Pruebas automáticas para revisar las reglas de pedidos usando datos de prueba en memoria, sin tocar la base real
final class OrderServiceTest extends TestCase
{
    private FakeOrders $orders;
    private OrderService $service;
    // Usuarios simulados con distintos roles para probar permisos
    private array $mesero = ['id' => 2, 'rol' => 'MESERO'];
    private array $cocina = ['id' => 3, 'rol' => 'COCINA'];

    protected function setUp(): void
    {
        // Prepara un entorno limpio antes de cada prueba con un catálogo simulado
        $this->orders = new FakeOrders();
        $catalog = new FakeCatalog([1 => ['id' => 1, 'precio' => '2.50']]); // el producto 2 está inactivo
        $this->service = new OrderService($this->orders, $catalog, new OrderCalculator(), new OrderStateMachine());
    }

    private function nuevoPedido(): int
    {
        // Atajo para crear rápido un pedido válido en mesa para usar en varias pruebas
        return $this->service->create($this->mesero, ['tipo' => 'MESA', 'mesa' => '5', 'items' => [['producto_id' => 1, 'cantidad' => 2]]]);
    }

    public function testCreaPedidoConTotalCalculado(): void
    {
        // Comprueba que al crear un pedido se sume bien el total y arranque como "Pendiente"
        $id = $this->nuevoPedido();
        $this->assertSame(5.0, $this->orders->rows[$id]['total']);
        $this->assertSame('Pendiente', $this->orders->rows[$id]['estado']);
    }

    public function testPedidoPorMesaExigeNumeroDeMesa(): void
    {
        // Verifica que si el pedido es para mesa y no se indica cuál, el sistema lo rechace
        $this->expectException(ValidationException::class);
        $this->service->create($this->mesero, ['tipo' => 'MESA', 'items' => [['producto_id' => 1, 'cantidad' => 1]]]);
    }

    public function testPedidoParaLlevarNoRequiereMesa(): void
    {
        // Revisa que un pedido para llevar se pueda crear sin número de mesa
        $id = $this->service->create($this->mesero, ['tipo' => 'LLEVAR', 'items' => [['producto_id' => 1, 'cantidad' => 1]]]);
        $this->assertNull($this->orders->rows[$id]['mesa']);
    }

    public function testNoPermiteProductoInactivo(): void
    {
        // Comprueba que no se pueda pedir un producto que está desactivado o no disponible
        $this->expectException(ValidationException::class);
        $this->service->create($this->mesero, ['tipo' => 'LLEVAR', 'items' => [['producto_id' => 2, 'cantidad' => 1]]]);
    }

    public function testCocinaPuedeIniciarPreparacion(): void
    {
        // Verifica que cocina sí pueda pasar un pedido de pendiente a en preparación
        $id = $this->nuevoPedido();
        $this->service->changeStatus($id, 'En preparación', $this->cocina);
        $this->assertSame('En preparación', $this->orders->rows[$id]['estado']);
    }

    public function testMeseroNoPuedeIniciarPreparacion(): void
    {
        // Comprueba que un mesero no tenga permiso para marcar un pedido como en preparación
        $id = $this->nuevoPedido();
        $this->expectException(ForbiddenException::class);
        $this->service->changeStatus($id, 'En preparación', $this->mesero);
    }

    public function testNoSeModificaPedidoListo(): void
    {
        // Verifica que un pedido ya "Listo" no se pueda seguir editando
        $id = $this->nuevoPedido();
        $this->orders->rows[$id]['estado'] = 'Listo';
        $this->expectException(ConflictException::class);
        $this->service->modify($id, ['items' => [['producto_id' => 1, 'cantidad' => 1]]]);
    }

    public function testPedidoInexistente(): void
    {
        // Comprueba que al intentar cambiar el estado de un pedido que no existe se avise el error
        $this->expectException(NotFoundException::class);
        $this->service->changeStatus(999, 'Listo', $this->cocina);
    }
}

// Catálogo falso en memoria para simular los productos disponibles durante las pruebas
final class FakeCatalog implements ProductCatalogInterface
{
    public function __construct(private array $products)
    {
    }

    public function findActiveByIds(array $ids): array
    {
        // Devuelve solo los productos activos de prueba que coincidan con los ids pedidos
        return array_intersect_key($this->products, array_flip($ids));
    }
}

// Repositorio falso en memoria para guardar pedidos en un arreglo temporal sin usar MySQL
final class FakeOrders implements OrderRepositoryInterface
{
    public array $rows = [];

    public function create(int $userId, string $tipo, ?string $mesa, array $lines, float $total): int
    {
        // Guarda el pedido en memoria y le asigna un número correlativo
        $id = count($this->rows) + 1;
        $this->rows[$id] = ['id' => $id, 'tipo' => $tipo, 'mesa' => $mesa, 'total' => $total, 'estado' => 'Pendiente'];
        return $id;
    }

    // Métodos mínimos para cumplir con el contrato del repositorio durante las pruebas
    public function find(int $id): ?array { return $this->rows[$id] ?? null; }
    public function details(int $id): ?array { return $this->rows[$id] ?? null; }
    public function search(array $filters): array { return array_values($this->rows); }
    public function replaceItems(int $id, array $lines, float $total): void { $this->rows[$id]['total'] = $total; }
    public function updateStatus(int $id, string $from, string $to, int $userId): void { $this->rows[$id]['estado'] = $to; }
    public function summary(): array { return []; }
}
