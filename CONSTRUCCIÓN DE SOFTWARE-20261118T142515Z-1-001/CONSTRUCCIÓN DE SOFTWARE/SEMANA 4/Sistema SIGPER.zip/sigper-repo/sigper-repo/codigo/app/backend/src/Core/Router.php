<?php
namespace Sigper\Core;

use Sigper\Exceptions\NotFoundException;

final class Router
{
    // Guarda aquí todas las rutas registradas del sistema
    private array $routes = [];

    // Recibe el guardia que revisa si el usuario tiene sesión y permiso
    public function __construct(private AuthGuard $guard)
    {
    }

    /** $roles: null = pública · [] = cualquier usuario autenticado · ['ADMIN',...] = solo esos roles. */
    public function add(string $method, string $pattern, callable $handler, ?array $roles = []): void
    {
        // Convierte cosas como {id} en un patrón para poder leer valores dinámicos de la URL
        $regex = '#^' . preg_replace('#\{(\w+)\}#', '(?P<$1>[^/]+)', $pattern) . '$#';
        $this->routes[] = [$method, $regex, $handler, $roles];
    }

    public function dispatch(Request $request): Response
    {
        // Busca una ruta que coincida con el método (GET, POST, etc.) y con la URL pedida
        foreach ($this->routes as [$method, $regex, $handler, $roles]) {
            if ($method !== $request->method || !preg_match($regex, $request->path, $m)) {
                continue;
            }
            // Si la ruta no es pública, revisa que el usuario esté autenticado y tenga el rol permitido
            if ($roles !== null) {
                $this->guard->check($request, $roles);
            }
            // Saca los datos variables de la ruta (como el id) y ejecuta la función que responde
            $params = array_filter($m, 'is_string', ARRAY_FILTER_USE_KEY);
            return $handler($request, $params);
        }
        // Si ninguna ruta coincide, avisa que no existe
        throw new NotFoundException('Ruta no encontrada');
    }
}