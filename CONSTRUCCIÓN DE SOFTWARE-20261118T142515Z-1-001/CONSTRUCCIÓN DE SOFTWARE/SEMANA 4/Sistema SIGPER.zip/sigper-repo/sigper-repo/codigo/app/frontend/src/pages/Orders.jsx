import { Fragment, useEffect, useState } from 'react';
import { api } from '../api.js';

// Lista oficial de estados posibles de un pedido en el sistema
export const ESTADOS = ['Pendiente', 'En preparación', 'Listo', 'Entregado', 'Cancelado'];

// Pantalla de pedidos e historial: permite filtrar órdenes, ver su detalle y marcar entregas o cancelaciones
export default function Orders({ user }) {
  // Filtros de búsqueda, listado de pedidos, conteo por estado, detalle abierto y mensaje de error
  const [filtros, setFiltros] = useState({ q: '', estado: '', fecha: '', tipo: '' });
  const [list, setList] = useState([]);
  const [resumen, setResumen] = useState([]);
  const [det, setDet] = useState(null);
  const [msg, setMsg] = useState('');

  // Consulta los pedidos filtrados y el resumen por estado al servidor
  const cargar = () => {
    const qs = new URLSearchParams(Object.entries(filtros).filter(([, v]) => v)).toString();
    api('/pedidos?' + qs).then(setList);
    api('/pedidos/resumen').then(setResumen);
  };

  // Refresca la lista cada vez que cambia alguno de los filtros
  useEffect(cargar, [filtros]);

  // Abre o cierra el detalle expandido de un pedido concreto
  const ver = async (id) => setDet(det?.id === id ? null : await api('/pedidos/' + id));

  // Cambia el estado de un pedido (por ejemplo, a Entregado o Cancelado) y recarga los datos
  const cambiar = async (id, estado) => {
    try { await api(`/pedidos/${id}/estado`, { method: 'PATCH', body: { estado } }); setMsg(''); setDet(null); cargar(); }
    catch (e) { setMsg(e.message); }
  };

  // Actualiza un campo específico dentro del objeto de filtros
  const set = (k) => (e) => setFiltros({ ...filtros, [k]: e.target.value });

  // Revisa si el usuario actual tiene permiso para una acción según su rol
  const puede = (rol) => user.rol === 'ADMIN' || user.rol === rol;

  return (
    <>
      {/* Encabezado con el título y las insignias de conteo por estado */}
      <div className="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
        <h4 className="mb-0 fw-bold">Pedidos e historial</h4>
        <div className="d-flex flex-wrap gap-1">
          {resumen.map((r) => (
            <span key={r.estado} className="badge text-bg-light border text-dark">{r.estado}: {r.n}</span>
          ))}
        </div>
      </div>

      {/* Muestra un mensaje rojo si falla alguna operación */}
      {msg && <div className="alert alert-danger py-2">{msg}</div>}

      {/* Barra de filtros por número de pedido, estado, fecha y tipo de entrega */}
      <div className="card p-3 mb-3">
        <div className="row g-2">
          <div className="col-sm-6 col-md-2">
            <input className="form-control" placeholder="N.º de pedido" value={filtros.q} onChange={set('q')} />
          </div>
          <div className="col-sm-6 col-md-3">
            <select className="form-select" value={filtros.estado} onChange={set('estado')}>
              <option value="">Todos los estados</option>
              {ESTADOS.map((e) => <option key={e}>{e}</option>)}
            </select>
          </div>
          <div className="col-sm-6 col-md-3">
            <input type="date" className="form-control" value={filtros.fecha} onChange={set('fecha')} />
          </div>
          <div className="col-sm-6 col-md-2">
            <select className="form-select" value={filtros.tipo} onChange={set('tipo')}>
              <option value="">Mesa y llevar</option>
              <option value="MESA">Mesa</option>
              <option value="LLEVAR">Para llevar</option>
            </select>
          </div>
        </div>
      </div>

      {/* Tabla principal de pedidos con acciones según el estado y el rol */}
      <div className="table-responsive">
        <table className="table table-hover align-middle">
          <thead>
            <tr><th>#</th><th>Fecha</th><th>Tipo</th><th>Responsable</th><th>Total</th><th>Estado</th><th className="text-end">Acciones</th></tr>
          </thead>
          <tbody>
            {list.map((p) => (
              <Fragment key={p.id}>
                <tr>
                  <td className="fw-semibold">#{p.id}</td>
                  <td>{new Date(p.fecha).toLocaleString()}</td>
                  <td>{p.tipo === 'MESA' ? `Mesa ${p.mesa}` : 'Para llevar'}</td>
                  <td>{p.responsable}</td>
                  <td className="fw-semibold">${Number(p.total).toFixed(2)}</td>
                  <td><span className="badge text-bg-info text-dark">{p.estado}</span></td>
                  <td className="text-end text-nowrap">
                    <button className="btn btn-sm btn-outline-dark me-1" onClick={() => ver(p.id)}>Detalle</button>
                    {p.estado === 'Listo' && puede('MESERO') && user.rol !== 'COCINA' &&
                      <button className="btn btn-sm btn-success me-1" onClick={() => cambiar(p.id, 'Entregado')}>Entregar</button>}
                    {['Pendiente', 'En preparación', 'Listo'].includes(p.estado) && puede('MESERO') && user.rol !== 'COCINA' &&
                      <button className="btn btn-sm btn-outline-danger" onClick={() => cambiar(p.id, 'Cancelado')}>Cancelar</button>}
                  </td>
                </tr>
                {/* Fila desplegable con los productos del pedido y su historial de cambios */}
                {det?.id === p.id && (
                  <tr>
                    <td colSpan="7" className="bg-light">
                      <ul className="mb-1">
                        {det.items.map((i) => (
                          <li key={i.id}>
                            {i.cantidad} × {i.nombre} (${Number(i.precio_unitario).toFixed(2)}) = ${Number(i.subtotal).toFixed(2)}
                            {i.observaciones && ` — ${i.observaciones}`}
                          </li>
                        ))}
                      </ul>
                      <small className="text-muted">
                        Historial: {det.historial.map((h) => `${h.estado_nuevo} (${h.usuario}, ${new Date(h.fecha).toLocaleTimeString()})`).join(' → ')}
                      </small>
                    </td>
                  </tr>
                )}
              </Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}