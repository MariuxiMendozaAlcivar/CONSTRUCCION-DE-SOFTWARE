import { useEffect, useState } from 'react';
import { api } from '../api.js';

// Pantalla de cocina para ver los pedidos activos (pendientes o en preparación) y avanzar su estado
export default function Kitchen() {
  // Lista de pedidos en cocina y mensaje de error si falla un cambio de estado
  const [pedidos, setPedidos] = useState([]);
  const [msg, setMsg] = useState('');

  // Trae los pedidos pendientes o en preparación con su detalle y los ordena del más antiguo al más reciente
  const cargar = () => api('/pedidos?detalle=1&estado=Pendiente,En preparación').then((d) => setPedidos([...d].reverse()));

  // Carga los pedidos al entrar y los refresca automáticamente cada 10 segundos; limpia el temporizador al salir
  useEffect(() => { cargar(); const t = setInterval(cargar, 10000); return () => clearInterval(t); }, []);

  // Envía el nuevo estado del pedido (por ejemplo, "En preparación" o "Listo") y actualiza la vista
  const cambiar = async (id, estado) => {
    try { await api(`/pedidos/${id}/estado`, { method: 'PATCH', body: { estado } }); setMsg(''); cargar(); }
    catch (e) { setMsg(e.message); }
  };

  return (
    <>
      {/* Encabezado con el título del panel y el contador de pedidos activos */}
      <div className="d-flex align-items-baseline justify-content-between flex-wrap gap-2 mb-3">
        <h4 className="mb-0 fw-bold">
          Panel de cocina <small className="text-muted fs-6 fw-normal">(se actualiza cada 10 s)</small>
        </h4>
        <span className="badge text-bg-light border text-dark">{pedidos.length} activos</span>
      </div>

      {/* Muestra un mensaje de error si ocurre algún problema al cambiar de estado */}
      {msg && <div className="alert alert-danger py-2">{msg}</div>}

      {/* Aviso cuando no hay pedidos por preparar */}
      {!pedidos.length && (
        <div className="card p-4 text-center text-muted">No hay pedidos pendientes.</div>
      )}

      {/* Tarjetas de pedidos con productos, notas especiales y botón para avanzar */}
      <div className="row g-3">
        {pedidos.map((p) => (
          <div key={p.id} className="col-md-6 col-lg-4">
            <div className={`card h-100 border-${p.estado === 'Pendiente' ? 'warning' : 'primary'} border-2`}>
              <div className="card-header bg-transparent d-flex justify-content-between align-items-center py-2">
                <strong>#{p.id} — {p.tipo === 'MESA' ? `Mesa ${p.mesa}` : 'Para llevar'}</strong>
                <span className="text-muted small">{new Date(p.fecha).toLocaleTimeString()}</span>
              </div>
              <ul className="list-group list-group-flush flex-grow-1">
                {p.items.map((i) => (
                  <li key={i.id} className="list-group-item">
                    <strong>{i.cantidad} ×</strong> {i.nombre}
                    {i.observaciones && <div className="text-danger small mt-1">⚠ {i.observaciones}</div>}
                  </li>
                ))}
              </ul>
              <div className="card-footer bg-transparent pt-2">
                {p.estado === 'Pendiente'
                  ? <button className="btn btn-warning w-100" onClick={() => cambiar(p.id, 'En preparación')}>Iniciar preparación</button>
                  : <button className="btn btn-success w-100" onClick={() => cambiar(p.id, 'Listo')}>Marcar como listo</button>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}