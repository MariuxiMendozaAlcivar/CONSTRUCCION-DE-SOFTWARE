<?php
namespace Sigper\Controllers;

use Sigper\Core\Request;
use Sigper\Core\Response;
use Sigper\Services\OrderService;

final class OrderController
{
    // Guarda el servicio que maneja toda la lógica de los pedidos
    public function __construct(private OrderService $orders)
    {
    }

    public function store(Request $r): Response
    {
        // Crea un pedido nuevo con los datos enviados y el usuario actual, y devuelve su id
        return Response::json(['id' => $this->orders->create($r->user, $r->body)], 201);
    }

    public function modify(Request $r, array $p): Response
    {
        // Modifica un pedido existente según su id
        $this->orders->modify((int) $p['id'], $r->body);
        return Response::json(['ok' => true]);
    }

    public function index(Request $r): Response
    {
        // Lista o filtra pedidos según los parámetros que lleguen en la URL
        return Response::json($this->orders->search($r->query));
    }

    public function summary(Request $r): Response
    {
        // Devuelve el resumen de pedidos (por ejemplo, cuántos hay por estado)
        return Response::json($this->orders->summary());
    }

    public function show(Request $r, array $p): Response
    {
        // Muestra el detalle completo de un pedido por su id
        return Response::json($this->orders->detail((int) $p['id']));
    }

    public function changeStatus(Request $r, array $p): Response
    {
        // Cambia el estado de un pedido (como Pendiente, En preparación o Listo)
        $this->orders->changeStatus((int) $p['id'], (string) ($r->body['estado'] ?? ''), $r->user);
        return Response::json(['ok' => true]);
    }
}
