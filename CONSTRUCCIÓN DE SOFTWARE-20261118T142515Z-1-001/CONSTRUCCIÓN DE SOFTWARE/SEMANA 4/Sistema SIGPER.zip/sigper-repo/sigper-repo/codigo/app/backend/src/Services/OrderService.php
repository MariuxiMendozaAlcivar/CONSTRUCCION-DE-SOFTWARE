<?php
namespace Sigper\Services;

use Sigper\Domain\OrderCalculator;
use Sigper\Domain\OrderStateMachine;
use Sigper\Domain\OrderStatus;
use Sigper\Exceptions\ConflictException;
use Sigper\Exceptions\NotFoundException;
use Sigper\Exceptions\ValidationException;
use Sigper\Repositories\OrderRepositoryInterface;
use Sigper\Repositories\ProductCatalogInterface;

/** Casos de uso de pedidos. Depende de abstracciones (DIP), no de PDO. */
// Coordina todo lo que pasa con un pedido (crear, editar, cambiar estado y consultar) apoyándose en las reglas y la base de datos
final class OrderService
{
    // Recibe las piezas necesarias para guardar pedidos, consultar precios activos, calcular totales y validar cambios de estado
    public function __construct(
        private OrderRepositoryInterface $orders,
        private ProductCatalogInterface $catalog,
        private OrderCalculator $calculator,
        private OrderStateMachine $stateMachine
    ) {
    }

    public function create(array $user, array $data): int
    {
        // Revisa que el tipo sea válido y, si es en mesa, exige el número de mesa
        $tipo = $data['tipo'] ?? '';
        if (!in_array($tipo, ['MESA', 'LLEVAR'], true)) {
            throw new ValidationException('Tipo de pedido inválido');
        }
        $mesa = trim((string) ($data['mesa'] ?? ''));
        if ($tipo === 'MESA' && $mesa === '') {
            throw new ValidationException('Indique el número de mesa');
        }
        // Calcula precios y total con datos reales del catálogo, y luego guarda el pedido
        $priced = $this->price($data['items'] ?? []);
        return $this->orders->create((int) $user['id'], $tipo, $tipo === 'MESA' ? $mesa : null, $priced['lines'], $priced['total']);
    }

    public function modify(int $id, array $data): void
    {
        // Verifica que el pedido exista y que todavía se pueda editar según su estado actual
        $order = $this->orders->find($id) ?? throw new NotFoundException('Pedido no encontrado');
        if (!OrderStatus::from($order['estado'])->isModifiable()) {
            throw new ConflictException('El pedido ya no admite cambios');
        }
        // Recalcula los productos y el total, y reemplaza el detalle del pedido
        $priced = $this->price($data['items'] ?? []);
        $this->orders->replaceItems($id, $priced['lines'], $priced['total']);
    }

    public function changeStatus(int $id, string $target, array $user): void
    {
        // Busca el pedido, valida que el estado destino exista y comprueba que el rol pueda hacer ese salto
        $order = $this->orders->find($id) ?? throw new NotFoundException('Pedido no encontrado');
        $to = OrderStatus::tryFrom($target) ?? throw new ValidationException('Estado inválido');
        $this->stateMachine->assertTransition(OrderStatus::from($order['estado']), $to, (string) $user['rol']);
        // Aplica el cambio de estado si sigue coincidiendo el estado anterior
        $this->orders->updateStatus($id, $order['estado'], $to->value, (int) $user['id']);
    }

    public function detail(int $id): array
    {
        // Devuelve la información completa del pedido o avisa si no existe
        return $this->orders->details($id) ?? throw new NotFoundException('Pedido no encontrado');
    }

    public function search(array $filters): array
    {
        // Busca pedidos según los filtros indicados
        return $this->orders->search($filters);
    }

    public function summary(): array
    {
        // Devuelve el conteo de pedidos agrupado por estado
        return $this->orders->summary();
    }

    private function price(mixed $items): array
    {
        // Verifica que venga una lista de productos y pide los precios actuales para armar líneas y total
        if (!is_array($items)) {
            throw new ValidationException('El pedido debe tener al menos un producto');
        }
        $items = array_values(array_filter($items, 'is_array'));
        $ids = array_map(fn($i) => (int) ($i['producto_id'] ?? 0), $items);
        return $this->calculator->build($items, $this->catalog->findActiveByIds($ids));
    }
}
