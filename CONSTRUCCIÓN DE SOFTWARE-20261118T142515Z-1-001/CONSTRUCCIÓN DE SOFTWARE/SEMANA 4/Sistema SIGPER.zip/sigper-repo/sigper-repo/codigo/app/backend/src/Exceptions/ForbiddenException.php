<?php
namespace Sigper\Exceptions;

// Error que salta cuando el usuario sí inició sesión, pero su rol no tiene permiso para hacer esto
final class ForbiddenException extends HttpException
{
    public function __construct(string $message = 'Sin permisos')
    {
        // Manda el mensaje y el código 403 (que significa acceso prohibido por falta de permiso)
        parent::__construct($message, 403);
    }
}
