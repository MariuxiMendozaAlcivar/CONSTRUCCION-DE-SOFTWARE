<?php
namespace Sigper\Core;

final class Response
{
    // Guarda los datos a devolver y el código de estado (por defecto 200 = todo bien)
    public function __construct(public readonly mixed $data, public readonly int $status = 200)
    {
    }

    public static function json(mixed $data, int $status = 200): self
    {
        // Forma rápida de armar una respuesta JSON con su código de estado
        return new self($data, $status);
    }

    public function send(): void
    {
        // Pone el código de respuesta, avisa que va en JSON con tildes/eñes y manda los datos
        http_response_code($this->status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($this->data, JSON_UNESCAPED_UNICODE);
    }
}
