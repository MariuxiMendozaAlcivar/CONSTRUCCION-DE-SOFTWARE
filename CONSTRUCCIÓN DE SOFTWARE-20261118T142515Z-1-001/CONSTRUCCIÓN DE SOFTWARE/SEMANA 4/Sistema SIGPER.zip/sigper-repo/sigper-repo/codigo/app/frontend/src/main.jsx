import React from 'react';
import ReactDOM from 'react-dom/client';
import { HashRouter } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './styles.css';
import App from './App.jsx';

// Punto de entrada de la interfaz: carga los estilos visuales y monta la aplicación dentro del navegador
// HashRouter: GitHub Pages no puede reescribir rutas, por eso se usa /#/ruta.
ReactDOM.createRoot(document.getElementById('root')).render(
  // Envuelve la aplicación con HashRouter para que cambiar de sección funcione sin depender de reglas de redirección en el servidor
  <HashRouter><App /></HashRouter>
);
