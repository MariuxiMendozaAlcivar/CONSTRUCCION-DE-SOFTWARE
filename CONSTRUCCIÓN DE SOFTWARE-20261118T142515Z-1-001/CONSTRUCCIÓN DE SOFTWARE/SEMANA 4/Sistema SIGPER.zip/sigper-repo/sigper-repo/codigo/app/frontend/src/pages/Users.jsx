import { useEffect, useState } from 'react';
import { api } from '../api.js';

// Valores iniciales limpios para registrar un nuevo usuario con rol de mesero por defecto
const vacio = { nombre: '', username: '', email: '', password: '', rol: 'MESERO' };

// Pantalla de administración para crear cuentas de personal, asignar roles y activar o desactivar accesos
export default function Users() {
  // Lista de usuarios registrados, datos del formulario y mensaje de error si ocurre un fallo
  const [list, setList] = useState([]);
  const [f, setF] = useState(vacio);
  const [msg, setMsg] = useState('');

  // Consulta al servidor la lista actualizada de usuarios
  const cargar = () => api('/usuarios').then(setList);

  // Carga los usuarios al abrir la pantalla
  useEffect(() => { cargar(); }, []);

  // Envía el formulario para crear un usuario nuevo y limpia los campos al completarse
  const crear = async (e) => {
    e.preventDefault();
    try { await api('/usuarios', { method: 'POST', body: f }); setF(vacio); setMsg(''); cargar(); }
    catch (err) { setMsg(err.message); }
  };

  // Alterna el estado activo/inactivo de un usuario para habilitar o bloquear su acceso
  const toggle = async (u) => {
    try { await api(`/usuarios/${u.id}/activo`, { method: 'PATCH', body: { activo: !u.activo } }); cargar(); }
    catch (err) { setMsg(err.message); }
  };

  // Actualiza un campo concreto del formulario
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  return (
    <>
      {/* Encabezado con el título de la sección y el total de usuarios */}
      <div className="d-flex align-items-center justify-content-between mb-3">
        <h4 className="mb-0 fw-bold">Gestión de usuarios</h4>
        <span className="text-muted small">{list.length} registrados</span>
      </div>

      {/* Aviso rojo si ocurre algún error al crear o cambiar el estado de un usuario */}
      {msg && <div className="alert alert-danger py-2">{msg}</div>}

      {/* Formulario para registrar un nuevo usuario y asignarle un rol */}
      <div className="card p-3 mb-4">
        <form onSubmit={crear} className="row g-2 align-items-center">
          <div className="col-md"><input className="form-control" placeholder="Nombre completo" required value={f.nombre} onChange={set('nombre')} /></div>
          <div className="col-md"><input className="form-control" placeholder="Usuario" required value={f.username} onChange={set('username')} /></div>
          <div className="col-md"><input className="form-control" type="email" placeholder="Correo" value={f.email} onChange={set('email')} /></div>
          <div className="col-md"><input className="form-control" type="password" placeholder="Contraseña" required value={f.password} onChange={set('password')} /></div>
          <div className="col-md">
            <select className="form-select" value={f.rol} onChange={set('rol')}>
              <option value="ADMIN">Administrador</option><option value="MESERO">Mesero</option><option value="COCINA">Cocina</option>
            </select>
          </div>
          <div className="col-auto"><button className="btn btn-primary px-3">Registrar</button></div>
        </form>
      </div>

      {/* Tabla de usuarios registrados con su rol, estado y botón para activar o desactivar */}
      <div className="table-responsive">
        <table className="table table-hover align-middle">
          <thead><tr><th>Nombre</th><th>Usuario</th><th>Correo</th><th>Rol</th><th>Estado</th><th className="text-end">Acción</th></tr></thead>
          <tbody>
            {list.map((u) => (
              <tr key={u.id}>
                <td className="fw-semibold">{u.nombre}</td>
                <td><code>{u.username}</code></td>
                <td>{u.email}</td>
                <td><span className="badge text-bg-light border text-dark">{u.rol}</span></td>
                <td>
                  <span className={`badge ${u.activo ? 'text-bg-success' : 'text-bg-secondary'}`}>
                    {u.activo ? 'Activo' : 'Inactivo'}
                  </span>
                </td>
                <td className="text-end">
                  <button className="btn btn-sm btn-outline-secondary" onClick={() => toggle(u)}>
                    {u.activo ? 'Desactivar' : 'Activar'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
