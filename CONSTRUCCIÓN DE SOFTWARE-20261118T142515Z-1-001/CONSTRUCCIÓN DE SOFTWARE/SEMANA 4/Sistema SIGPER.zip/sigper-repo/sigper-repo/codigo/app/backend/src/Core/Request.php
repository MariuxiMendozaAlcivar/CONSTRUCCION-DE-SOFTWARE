<?php
namespace Sigper\Core;

use Sigper\Config\Env;
use Sigper\Exceptions\ValidationException;

final class Request
{
    /** Usuario autenticado (lo asigna AuthGuard). */
    // Aquí quedan los datos del usuario cuando pasa la revisión de acceso
    public ?array $user = null;

    public function __construct(
        public readonly string $method,
        public readonly string $path,
        public readonly array $query,
        public readonly array $body,
        public readonly string $authorization = ''
    ) {
    }

    public static function fromGlobals(): self
    {
        // Saca la ruta pedida sin parámetros y le quita la carpeta base si el proyecto está en una subruta
        $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $base = rtrim((string) Env::get('BASE_PATH', ''), '/');
        if ($base !== '' && strncmp($path, $base, strlen($base)) === 0) {
            $path = substr($path, strlen($base));
        }
        // Lee los datos que llegaron en el cuerpo de la petición y revisa que vengan en formato JSON válido
        $raw = file_get_contents('php://input');
        $body = $raw ? json_decode($raw, true) : [];
        if (!is_array($body)) {
            throw new ValidationException('El cuerpo de la petición no es JSON válido');
        }
        // Busca la cabecera de autorización donde suele venir el token del usuario
        $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
        return new self($_SERVER['REQUEST_METHOD'] ?? 'GET', rtrim($path, '/') ?: '/', $_GET, $body, $auth);
    }

    public function bearer(): string
    {
        // Quita la palabra "Bearer " para quedarse solo con el token limpio
        return trim((string) preg_replace('/^Bearer\s+/i', '', $this->authorization));
    }
}