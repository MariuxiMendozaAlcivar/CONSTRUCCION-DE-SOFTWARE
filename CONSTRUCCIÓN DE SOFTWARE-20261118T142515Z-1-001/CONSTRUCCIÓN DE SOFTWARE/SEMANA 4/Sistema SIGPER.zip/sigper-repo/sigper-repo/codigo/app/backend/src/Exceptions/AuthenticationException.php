<?php
namespace Sigper\Exceptions;

// Error que salta cuando alguien intenta entrar sin haber iniciado sesión o con sesión inválida
final class AuthenticationException extends HttpException
{
    public function __construct(string $message = 'No autenticado')
    {
        // Manda el mensaje y el código 401 (que significa que falta autenticarse)
        parent::__construct($message, 401);
    }
}
