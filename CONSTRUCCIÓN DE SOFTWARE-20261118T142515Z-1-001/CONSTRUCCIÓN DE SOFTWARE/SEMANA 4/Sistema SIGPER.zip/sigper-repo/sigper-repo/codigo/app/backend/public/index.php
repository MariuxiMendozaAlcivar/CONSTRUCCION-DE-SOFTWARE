<?php
// Trae el archivo que carga las clases del proyecto automáticamente
require __DIR__ . '/../src/autoload.php';

use Sigper\Config\Env;
use Sigper\Controllers\{AuthController, CategoryController, OrderController, ProductController, UserController};
use Sigper\Core\{AuthGuard, Database, Request, Response, Router};
use Sigper\Domain\{OrderCalculator, OrderStateMachine};
use Sigper\Exceptions\HttpException;
use Sigper\Repositories\{CategoryRepository, PdoOrderRepository, ProductRepository, UserRepository};
use Sigper\Security\{JwtService, PasswordHasher};
use Sigper\Services\{AuthService, OrderService};

// Lee la configuración del archivo .env
Env::load(__DIR__ . '/../.env');

// Permite que el frontend se conecte al backend y responde rápido si el navegador pregunta antes (OPTIONS)
header('Access-Control-Allow-Origin: ' . Env::get('CORS_ORIGIN', '*'));
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

try {
    // ---- Raíz de composición ----
    // Aquí se arman y conectan todas las piezas principales del sistema antes de atender peticiones
    $db = Database::fromEnv();
    $jwt = new JwtService((string) Env::get('JWT_SECRET', ''));
    $hasher = new PasswordHasher();
    $userRepo = new UserRepository($db);
    $categoryRepo = new CategoryRepository($db);
    $productRepo = new ProductRepository($db);
    $orderService = new OrderService(new PdoOrderRepository($db), $productRepo, new OrderCalculator(), new OrderStateMachine());

    $auth = new AuthController(new AuthService($userRepo, $hasher, $jwt));
    $users = new UserController($userRepo, $hasher);
    $categories = new CategoryController($categoryRepo);
    $products = new ProductController($productRepo, $categoryRepo);
    $orders = new OrderController($orderService);

    // ---- Rutas ----
    // Define quién puede entrar a cada ruta y qué función se ejecuta al pedirla
    $admin = ['ADMIN'];
    $waiter = ['MESERO', 'ADMIN'];
    $router = new Router(new AuthGuard($jwt));
    $router->add('POST', '/api/auth/login', [$auth, 'login'], null); // Cualquiera puede intentar iniciar sesión aquí
    $router->add('GET', '/api/auth/me', [$auth, 'me']);

    $router->add('GET', '/api/usuarios', [$users, 'index'], $admin);
    $router->add('POST', '/api/usuarios', [$users, 'store'], $admin);
    $router->add('PUT', '/api/usuarios/{id}', [$users, 'update'], $admin);
    $router->add('PATCH', '/api/usuarios/{id}/activo', [$users, 'setActive'], $admin);

    $router->add('GET', '/api/categorias', [$categories, 'index']);
    $router->add('POST', '/api/categorias', [$categories, 'store'], $admin);
    $router->add('PUT', '/api/categorias/{id}', [$categories, 'update'], $admin);

    $router->add('GET', '/api/productos', [$products, 'index']);
    $router->add('POST', '/api/productos', [$products, 'store'], $admin);
    $router->add('PUT', '/api/productos/{id}', [$products, 'update'], $admin);

    $router->add('POST', '/api/pedidos', [$orders, 'store'], $waiter);
    $router->add('GET', '/api/pedidos/resumen', [$orders, 'summary']);
    $router->add('GET', '/api/pedidos', [$orders, 'index']);
    $router->add('GET', '/api/pedidos/{id}', [$orders, 'show']);
    $router->add('PUT', '/api/pedidos/{id}', [$orders, 'modify'], $waiter);
    $router->add('PATCH', '/api/pedidos/{id}/estado', [$orders, 'changeStatus']);

    // Busca la ruta que pidió el usuario y ejecuta lo que toca
    $response = $router->dispatch(Request::fromGlobals());
} catch (HttpException $e) {
    // Si algo salió mal pero ya sabemos qué pasó (como falta permiso o no existe), devuelve ese mensaje
    $response = Response::json(['error' => $e->getMessage()], $e->status());
} catch (PDOException $e) {
    // Si falló la base de datos, guarda el detalle en el log y muestra un mensaje simple
    error_log('[SIGPER][DB] ' . $e->getMessage());
    $response = Response::json(['error' => 'Base de datos no disponible, intente nuevamente'], 503);
} catch (Throwable $e) {
    // Si ocurrió cualquier otro error raro, lo anota en el log y avisa que hubo un fallo interno
    error_log('[SIGPER] ' . $e);
    $response = Response::json(['error' => 'Error interno del servidor'], 500);
}
// Manda la respuesta final al navegador o frontend
$response->send();