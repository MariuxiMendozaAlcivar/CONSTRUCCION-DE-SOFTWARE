<?php
namespace Sigper\Repositories;

// Contrato cortito con lo único que necesita el servicio de pedidos para consultar productos activos
/** Interfaz mínima que necesita OrderService (Principio de Segregación de Interfaces). */
interface ProductCatalogInterface
{
    /** @return array productos activos indexados por id */
    // Busca productos disponibles a partir de una lista de ids y los devuelve listos por id
    public function findActiveByIds(array $ids): array;
}
