<?php
namespace Sigper\Tests;

use InvalidArgumentException;
use PHPUnit\Framework\TestCase;
use Sigper\Exceptions\AuthenticationException;
use Sigper\Security\JwtService;

// Pruebas automáticas para verificar que el manejo de tokens de sesión funcione bien y rechace intentos falsos o vencidos
final class JwtServiceTest extends TestCase
{
    public function testEmiteYVerificaToken(): void
    {
        // Comprueba que al crear un token y leerlo de vuelta se conservan los datos del usuario
        $jwt = new JwtService('secreto-de-prueba');
        $data = $jwt->verify($jwt->issue(['id' => 7, 'rol' => 'ADMIN']));
        $this->assertSame(7, $data['id']);
        $this->assertSame('ADMIN', $data['rol']);
    }

    public function testTokenManipuladoEsRechazado(): void
    {
        // Simula que alguien altera el contenido del token para volverse ADMIN y verifica que el sistema lo bloquee
        $jwt = new JwtService('secreto-de-prueba');
        [$h, $p, $s] = explode('.', $jwt->issue(['rol' => 'COCINA']));
        $falso = rtrim(strtr(base64_encode('{"rol":"ADMIN","exp":9999999999}'), '+/', '-_'), '=');
        $this->expectException(AuthenticationException::class);
        $jwt->verify("$h.$falso.$s");
    }

    public function testTokenExpiradoEsRechazado(): void
    {
        // Crea un token con fecha de emisión de hace una hora y comprueba que se rechace por haber caducado
        $jwt = new JwtService('secreto-de-prueba', 60);
        $token = $jwt->issue(['id' => 1], time() - 3600);
        $this->expectException(AuthenticationException::class);
        $jwt->verify($token);
    }

    public function testSecretoVacioNoSePermite(): void
    {
        // Verifica que el sistema no permita arrancar el servicio de tokens sin una clave secreta
        $this->expectException(InvalidArgumentException::class);
        new JwtService('');
    }
}