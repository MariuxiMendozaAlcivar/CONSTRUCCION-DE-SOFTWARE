<?php
namespace Sigper\Controllers;

use Sigper\Core\Request;
use Sigper\Core\Response;
use Sigper\Core\Validator;
use Sigper\Repositories\CategoryRepository;
use Sigper\Repositories\ProductRepository;

final class ProductController
{
    // Guarda los accesos a la base de datos para productos y categorías
    public function __construct(private ProductRepository $products, private CategoryRepository $categories)
    {
    }

    public function index(Request $r): Response
    {
        // Devuelve todos los productos (o solo los disponibles si viene ese filtro)
        return Response::json($this->products->all(!empty($r->query['disponibles'])));
    }

    public function store(Request $r): Response
    {
        // Revisa los datos del producto y lo guarda en la base de datos
        $this->validate($r->body);
        return Response::json(['id' => $this->products->create($r->body)], 201);
    }

    public function update(Request $r, array $p): Response
    {
        // Revisa los datos y actualiza el producto según su id
        $this->validate($r->body);
        $this->products->update((int) $p['id'], $r->body);
        return Response::json(['ok' => true]);
    }

    private function validate(array $d): void
    {
        // Verifica campos obligatorios, que el precio sea mayor a 0 y que la categoría exista
        Validator::required($d, ['codigo', 'nombre', 'categoria_id']);
        Validator::assert(is_numeric($d['precio'] ?? null) && (float) $d['precio'] > 0, 'El precio debe ser positivo');
        Validator::assert($this->categories->exists((int) $d['categoria_id']), 'Categoría inexistente');
    }
}
