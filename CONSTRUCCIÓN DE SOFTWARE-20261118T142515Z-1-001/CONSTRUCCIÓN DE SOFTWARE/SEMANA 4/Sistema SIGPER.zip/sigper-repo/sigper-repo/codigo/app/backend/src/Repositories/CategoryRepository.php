<?php
namespace Sigper\Repositories;

use PDOException;
use Sigper\Core\Database;
use Sigper\Exceptions\ConflictException;

final class CategoryRepository
{
    // Guarda la conexión a la base de datos para consultar o guardar categorías
    public function __construct(private Database $db)
    {
    }

    public function all(bool $onlyActive = false): array
    {
        // Trae las categorías ordenadas por nombre; si se pide, filtra solo las que están activas
        $sql = 'SELECT * FROM categorias' . ($onlyActive ? ' WHERE activo=1' : '') . ' ORDER BY nombre';
        return $this->db->pdo()->query($sql)->fetchAll();
    }

    public function exists(int $id): bool
    {
        // Revisa rápido si existe una categoría con ese id
        $st = $this->db->pdo()->prepare('SELECT 1 FROM categorias WHERE id=?');
        $st->execute([$id]);
        return (bool) $st->fetchColumn();
    }

    public function create(string $nombre, ?string $descripcion): int
    {
        // Guarda una nueva categoría y devuelve su id; si ya existe otra igual, avisa el conflicto
        try {
            $this->db->pdo()->prepare('INSERT INTO categorias (nombre,descripcion) VALUES (?,?)')->execute([$nombre, $descripcion]);
            return (int) $this->db->pdo()->lastInsertId();
        } catch (PDOException $e) {
            throw $e->getCode() === '23000' ? new ConflictException('La categoría ya existe') : $e;
        }
    }

    public function update(int $id, string $nombre, ?string $descripcion, bool $activo): void
    {
        // Actualiza nombre, descripción y estado activo de una categoría; avisa si el nombre queda repetido
        try {
            $this->db->pdo()->prepare('UPDATE categorias SET nombre=?, descripcion=?, activo=? WHERE id=?')
                ->execute([$nombre, $descripcion, $activo ? 1 : 0, $id]);
        } catch (PDOException $e) {
            throw $e->getCode() === '23000' ? new ConflictException('Nombre de categoría duplicado') : $e;
        }
    }
}
