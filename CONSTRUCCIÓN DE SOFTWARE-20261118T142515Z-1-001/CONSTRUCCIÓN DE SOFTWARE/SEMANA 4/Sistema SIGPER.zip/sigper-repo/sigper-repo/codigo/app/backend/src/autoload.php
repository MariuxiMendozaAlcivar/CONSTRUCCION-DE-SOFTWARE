<?php
// Autoloader PSR-4 propio: namespace Sigper\ => carpeta src/ (no requiere Composer en producción).
// Busca y carga automáticamente el archivo de cada clase cuando el código la necesita, sin tener que escribir "require" en todos lados
spl_autoload_register(function (string $class): void {
    // Solo se encarga de las clases que empiezan con "Sigper\"; si es de otra librería, lo deja pasar
    $prefix = 'Sigper\\';
    if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
        return;
    }
    // Convierte el nombre de la clase (con sus carpetas) en la ruta real del archivo .php dentro de esta carpeta
    $file = __DIR__ . '/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
    // Si el archivo existe, lo incluye para que PHP pueda usar la clase
    if (is_file($file)) {
        require $file;
    }
});