<?php
namespace Sigper\Security;

// Se encarga de proteger las contraseñas para no guardarlas tal como las escribe el usuario
final class PasswordHasher
{
    public function hash(string $plain): string
    {
        // Transforma la contraseña en una versión cifrada (hash bcrypt) difícil de revertir
        return password_hash($plain, PASSWORD_BCRYPT);
    }

    public function verify(string $plain, string $hash): bool
    {
        // Comprueba si la contraseña ingresada coincide con la versión cifrada guardada
        return password_verify($plain, $hash);
    }
}
