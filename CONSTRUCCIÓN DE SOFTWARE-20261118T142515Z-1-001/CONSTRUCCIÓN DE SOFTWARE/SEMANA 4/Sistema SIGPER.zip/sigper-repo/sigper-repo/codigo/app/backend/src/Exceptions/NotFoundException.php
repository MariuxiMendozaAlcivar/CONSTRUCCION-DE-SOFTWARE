<?php
namespace Sigper\Exceptions;

// Error que salta cuando se busca algo que no existe (como una ruta o un registro inexistente)
final class NotFoundException extends HttpException
{
    public function __construct(string $message = 'No encontrado')
    {
        // Manda el mensaje y el código 404 (el clásico "no encontrado")
        parent::__construct($message, 404);
    }
}
