<?php
namespace Sigper\Security;

use InvalidArgumentException;
use Sigper\Exceptions\AuthenticationException;

/** JWT HS256 implementado con PHP puro. */
// Se encarga de crear y revisar los pases de sesión (tokens JWT) para que el usuario no tenga que loguearse en cada clic
final class JwtService
{
    public function __construct(private string $secret, private int $ttl = 28800)
    {
        // Recibe la clave secreta y el tiempo de vida del token (28800 segundos = 8 horas por defecto); exige que haya clave
        if ($secret === '') {
            throw new InvalidArgumentException('JWT_SECRET no configurado');
        }
    }

    private static function enc(string $s): string
    {
        // Codifica texto en formato Base64 seguro para URLs (sin caracteres raros ni signos "=" al final)
        return rtrim(strtr(base64_encode($s), '+/', '-_'), '=');
    }

    private static function dec(string $s): string
    {
        // Revierte la codificación Base64 segura para URLs y recupera el texto original
        return (string) base64_decode(strtr($s, '-_', '+/'));
    }

    private function sign(string $data): string
    {
        // Genera la firma digital usando la clave secreta y el algoritmo HMAC-SHA256 para evitar alteraciones
        return self::enc(hash_hmac('sha256', $data, $this->secret, true));
    }

    public function issue(array $claims, ?int $now = null): string
    {
        // Arma y firma un token nuevo con los datos del usuario, la hora de emisión y la hora de vencimiento
        $now = $now ?? time();
        $head = self::enc(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
        $body = self::enc(json_encode($claims + ['iat' => $now, 'exp' => $now + $this->ttl]));
        return "$head.$body." . $this->sign("$head.$body");
    }

    public function verify(string $token, ?int $now = null): array
    {
        // Revisa que el token tenga 3 partes y que su firma coincida (comparación segura contra ataques de tiempo)
        $parts = explode('.', $token);
        if (count($parts) !== 3 || !hash_equals($this->sign("$parts[0].$parts[1]"), $parts[2])) {
            throw new AuthenticationException('Token inválido');
        }
        // Lee los datos internos y comprueba que el token no haya caducado
        $data = json_decode(self::dec($parts[1]), true);
        if (!is_array($data) || ($data['exp'] ?? 0) < ($now ?? time())) {
            throw new AuthenticationException('Sesión expirada');
        }
        return $data;
    }
}