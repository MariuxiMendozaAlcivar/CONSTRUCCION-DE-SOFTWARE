<?php
namespace Sigper\Core;

use Sigper\Exceptions\ValidationException;

final class Validator
{
    public static function required(array $data, array $fields): void
    {
        // Revisa uno por uno los campos obligatorios y avisa si alguno falta o está vacío
        foreach ($fields as $f) {
            if (!isset($data[$f]) || trim((string) $data[$f]) === '') {
                throw new ValidationException("El campo '$f' es obligatorio");
            }
        }
    }

    public static function assert(bool $condition, string $message): void
    {
        // Si no se cumple una condición (por ejemplo, precio mayor a 0), lanza el mensaje de error
        if (!$condition) {
            throw new ValidationException($message);
        }
    }
}
