<?php
namespace Sigper\Exceptions;

// Error que salta cuando los datos enviados no cumplen lo esperado (por ejemplo, falta un campo o un precio es negativo)
final class ValidationException extends HttpException
{
    public function __construct(string $message = 'Datos inválidos')
    {
        // Manda el mensaje y el código 422 (los datos llegaron, pero no son válidos para procesarse)
        parent::__construct($message, 422);
    }
}
