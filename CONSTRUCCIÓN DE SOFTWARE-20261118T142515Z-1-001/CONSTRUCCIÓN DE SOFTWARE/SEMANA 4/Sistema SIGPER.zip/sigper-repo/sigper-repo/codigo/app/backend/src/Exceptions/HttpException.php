<?php
namespace Sigper\Exceptions;

/** Excepción base: lleva el código HTTP que se devolverá al cliente. */
// Base para los errores de la API: guarda el mensaje y el código numéricode respuesta
class HttpException extends \RuntimeException
{
    public function __construct(string $message, private int $status = 500)
    {
        parent::__construct($message);
    }

    public function status(): int
    {
        // Devuelve el código de error (como 401, 403, 404, 409 o 500) para responder bien
        return $this->status;
    }
}
