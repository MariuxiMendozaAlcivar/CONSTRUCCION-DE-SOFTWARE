<?php
namespace Sigper\Controllers;

use Sigper\Core\Request;
use Sigper\Core\Response;
use Sigper\Core\Validator;
use Sigper\Services\AuthService;

final class AuthController
{
    // Recibe el servicio que se encarga de revisar el inicio de sesión
    public function __construct(private AuthService $auth)
    {
    }

    public function login(Request $r): Response
    {
        // Revisa que hayan mandado usuario/correo y contraseña
        Validator::required($r->body, ['identificador', 'password']);
        // Intenta iniciar sesión y devuelve la respuesta en formato JSON
        return Response::json($this->auth->login((string) $r->body['identificador'], (string) $r->body['password']));
    }

    public function me(Request $r): Response
    {
        // Devuelve los datos del usuario que ya inició sesión
        return Response::json($r->user);
    }
}
