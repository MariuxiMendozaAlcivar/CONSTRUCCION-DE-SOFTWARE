<?php
namespace Sigper\Core;

use PDO;
use PDOException;
use Sigper\Config\Env;

/** Conexión PDO perezosa con un reintento (tolerancia a fallos de conexión). */
final class Database
{
    // Guarda la conexión a la base de datos una vez que se abre para reutilizarla
    private ?PDO $pdo = null;

    public function __construct(
        private string $host, private string $name, private string $user,
        private string $pass, private string $port = '3306'
    ) {
    }

    public static function fromEnv(): self
    {
        // Toma los datos de conexión de la base de datos desde la configuración (.env)
        return new self(
            Env::get('DB_HOST', 'localhost'), Env::get('DB_NAME', 'sigper'),
            Env::get('DB_USER', 'root'), Env::get('DB_PASSWORD', ''), Env::get('DB_PORT', '3306')
        );
    }

    public function pdo(): PDO
    {
        // Si ya está conectada, devuelve la conexión que ya tenemos abierta
        if ($this->pdo !== null) {
            return $this->pdo;
        }
        $dsn = "mysql:host={$this->host};port={$this->port};dbname={$this->name};charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];
        // Intenta conectar; si falla la primera vez, espera un poquito y lo intenta una vez más
        for ($attempt = 1; ; $attempt++) {
            try {
                return $this->pdo = new PDO($dsn, $this->user, $this->pass, $options);
            } catch (PDOException $e) {
                if ($attempt >= 2) {
                    throw $e;
                }
                usleep(300000);
            }
        }
    }
}
