<?php
namespace Sigper\Exceptions;

// Error que salta cuando se intenta hacer algo que choca con cómo están las cosas ahorita (por ejemplo, un cambio de estado no permitido)
final class ConflictException extends HttpException
{
    public function __construct(string $message = 'Conflicto con el estado actual')
    {
        // Manda el mensaje y el código 409 (que avisa que hubo un conflicto de estado)
        parent::__construct($message, 409);
    }
}