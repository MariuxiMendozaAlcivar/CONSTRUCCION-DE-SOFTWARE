-- Selecciona la base de datos 'sigper' para insertar los registros iniciales.
USE sigper;

-- Los usuarios iniciales (admin / mesero / cocina) se crean con:  php bin/seed.php
-- porque PHP genera el hash de la contraseña (password_hash / bcrypt).

-- Inserta las categorías base del menú (quedan activas por defecto según la definición de la tabla).
INSERT INTO categorias (nombre, descripcion) VALUES
  ('Bebidas', 'Jugos y gaseosas'), -- Categoría para bebidas naturales y embotelladas.
  ('Platos fuertes', 'Almuerzos'), -- Categoría para platos principales.
  ('Postres', 'Dulces'); -- Categoría para postres y dulces.

-- Inserta los productos iniciales referenciando los IDs correspondientes de 'categorias' (1: Bebidas, 2: Platos fuertes, 3: Postres).
INSERT INTO productos (codigo, nombre, descripcion, precio, categoria_id) VALUES
  ('BEB-01', 'Jugo natural', 'Vaso 12 oz', 2.50, 1), -- Producto de categoría Bebidas.
  ('BEB-02', 'Gaseosa', 'Botella personal', 1.50, 1), -- Producto de categoría Bebidas.
  ('PLA-01', 'Seco de pollo', 'Con arroz y ensalada', 5.00, 2), -- Producto de categoría Platos fuertes.
  ('PLA-02', 'Encebollado', 'Con pan', 4.00, 2), -- Producto de categoría Platos fuertes.
  ('POS-01', 'Flan de vainilla', 'Porción individual', 2.00, 3); -- Producto de categoría Postres.