<?php
namespace Sigper\Core;

use Sigper\Exceptions\NotFoundException;

final class Router
{
    private array $routes = [];

    public function __construct(private AuthGuard $guard)
    {
    }

    /** $roles: null = pública · [] = cualquier usuario autenticado · ['ADMIN',...] = solo esos roles. */
    public function add(string $method, string $pattern, callable $handler, ?array $roles = []): void
    {
        $regex = '#^' . preg_replace('#\{(\w+)\}#', '(?P<$1>[^/]+)', $pattern) . '$#';
        $this->routes[] = [$method, $regex, $handler, $roles];
    }

    public function dispatch(Request $request): Response
    {
        foreach ($this->routes as [$method, $regex, $handler, $roles]) {
            if ($method !== $request->method || !preg_match($regex, $request->path, $m)) {
                continue;
            }
            if ($roles !== null) {
                $this->guard->check($request, $roles);
            }
            $params = array_filter($m, 'is_string', ARRAY_FILTER_USE_KEY);
            return $handler($request, $params);
        }
        throw new NotFoundException('Ruta no encontrada');
    }
}
