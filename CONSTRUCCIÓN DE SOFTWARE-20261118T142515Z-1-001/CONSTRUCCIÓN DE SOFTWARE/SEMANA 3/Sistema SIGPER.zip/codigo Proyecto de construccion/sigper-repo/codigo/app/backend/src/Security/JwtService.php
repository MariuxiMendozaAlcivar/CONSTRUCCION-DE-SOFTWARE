<?php
namespace Sigper\Security;

use InvalidArgumentException;
use Sigper\Exceptions\AuthenticationException;

/** JWT HS256 implementado con PHP puro. */
final class JwtService
{
    public function __construct(private string $secret, private int $ttl = 28800)
    {
        if ($secret === '') {
            throw new InvalidArgumentException('JWT_SECRET no configurado');
        }
    }

    private static function enc(string $s): string
    {
        return rtrim(strtr(base64_encode($s), '+/', '-_'), '=');
    }

    private static function dec(string $s): string
    {
        return (string) base64_decode(strtr($s, '-_', '+/'));
    }

    private function sign(string $data): string
    {
        return self::enc(hash_hmac('sha256', $data, $this->secret, true));
    }

    public function issue(array $claims, ?int $now = null): string
    {
        $now = $now ?? time();
        $head = self::enc(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
        $body = self::enc(json_encode($claims + ['iat' => $now, 'exp' => $now + $this->ttl]));
        return "$head.$body." . $this->sign("$head.$body");
    }

    public function verify(string $token, ?int $now = null): array
    {
        $parts = explode('.', $token);
        if (count($parts) !== 3 || !hash_equals($this->sign("$parts[0].$parts[1]"), $parts[2])) {
            throw new AuthenticationException('Token inválido');
        }
        $data = json_decode(self::dec($parts[1]), true);
        if (!is_array($data) || ($data['exp'] ?? 0) < ($now ?? time())) {
            throw new AuthenticationException('Sesión expirada');
        }
        return $data;
    }
}
