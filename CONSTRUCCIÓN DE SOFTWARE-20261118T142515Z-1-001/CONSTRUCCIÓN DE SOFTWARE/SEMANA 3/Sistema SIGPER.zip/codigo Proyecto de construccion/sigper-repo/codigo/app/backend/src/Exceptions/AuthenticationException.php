<?php
namespace Sigper\Exceptions;

final class AuthenticationException extends HttpException
{
    public function __construct(string $message = 'No autenticado')
    {
        parent::__construct($message, 401);
    }
}
