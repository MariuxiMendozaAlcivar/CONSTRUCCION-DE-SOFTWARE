<?php
namespace Sigper\Repositories;

use PDOException;
use Sigper\Core\Database;
use Sigper\Exceptions\ConflictException;

final class ProductRepository implements ProductCatalogInterface
{
    public function __construct(private Database $db)
    {
    }

    public function all(bool $onlyAvailable = false): array
    {
        $sql = 'SELECT p.*, c.nombre AS categoria FROM productos p JOIN categorias c ON c.id=p.categoria_id'
            . ($onlyAvailable ? ' WHERE p.activo=1 AND c.activo=1' : '') . ' ORDER BY c.nombre, p.nombre';
        return array_map(fn(array $r) => ['precio' => (float) $r['precio']] + $r, $this->db->pdo()->query($sql)->fetchAll());
    }

    public function findActiveByIds(array $ids): array
    {
        $ids = array_values(array_unique(array_map('intval', $ids)));
        if ($ids === []) {
            return [];
        }
        $in = implode(',', array_fill(0, count($ids), '?'));
        $st = $this->db->pdo()->prepare("SELECT id, precio FROM productos WHERE activo=1 AND id IN ($in)");
        $st->execute($ids);
        $out = [];
        foreach ($st->fetchAll() as $row) {
            $out[(int) $row['id']] = $row;
        }
        return $out;
    }

    public function create(array $p): int
    {
        try {
            $this->db->pdo()->prepare('INSERT INTO productos (codigo,nombre,descripcion,precio,categoria_id,imagen_url) VALUES (?,?,?,?,?,?)')
                ->execute([$p['codigo'], $p['nombre'], ($p['descripcion'] ?? '') ?: null, $p['precio'], $p['categoria_id'], ($p['imagen_url'] ?? '') ?: null]);
            return (int) $this->db->pdo()->lastInsertId();
        } catch (PDOException $e) {
            throw $e->getCode() === '23000' ? new ConflictException('Código de producto duplicado') : $e;
        }
    }

    public function update(int $id, array $p): void
    {
        try {
            $this->db->pdo()->prepare('UPDATE productos SET codigo=?,nombre=?,descripcion=?,precio=?,categoria_id=?,imagen_url=?,activo=? WHERE id=?')
                ->execute([$p['codigo'], $p['nombre'], ($p['descripcion'] ?? '') ?: null, $p['precio'], $p['categoria_id'],
                    ($p['imagen_url'] ?? '') ?: null, !empty($p['activo']) ? 1 : 0, $id]);
        } catch (PDOException $e) {
            throw $e->getCode() === '23000' ? new ConflictException('Código de producto duplicado') : $e;
        }
    }
}
