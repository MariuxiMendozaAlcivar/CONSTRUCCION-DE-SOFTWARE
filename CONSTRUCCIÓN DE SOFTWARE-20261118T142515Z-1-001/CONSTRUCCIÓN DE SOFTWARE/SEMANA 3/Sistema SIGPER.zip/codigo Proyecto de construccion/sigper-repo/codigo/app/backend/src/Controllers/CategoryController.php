<?php
namespace Sigper\Controllers;

use Sigper\Core\Request;
use Sigper\Core\Response;
use Sigper\Core\Validator;
use Sigper\Repositories\CategoryRepository;

final class CategoryController
{
    public function __construct(private CategoryRepository $categories)
    {
    }

    public function index(Request $r): Response
    {
        return Response::json($this->categories->all(!empty($r->query['activas'])));
    }

    public function store(Request $r): Response
    {
        Validator::required($r->body, ['nombre']);
        $id = $this->categories->create(trim($r->body['nombre']), ($r->body['descripcion'] ?? '') ?: null);
        return Response::json(['id' => $id], 201);
    }

    public function update(Request $r, array $p): Response
    {
        Validator::required($r->body, ['nombre']);
        $this->categories->update((int) $p['id'], trim($r->body['nombre']), ($r->body['descripcion'] ?? '') ?: null, !empty($r->body['activo']));
        return Response::json(['ok' => true]);
    }
}
