import { useEffect, useState } from 'react';
import { api } from '../api.js';

const vacio = { nombre: '', username: '', email: '', password: '', rol: 'MESERO' };

export default function Users() {
  const [list, setList] = useState([]);
  const [f, setF] = useState(vacio);
  const [msg, setMsg] = useState('');
  const cargar = () => api('/usuarios').then(setList);
  useEffect(() => { cargar(); }, []);

  const crear = async (e) => {
    e.preventDefault();
    try { await api('/usuarios', { method: 'POST', body: f }); setF(vacio); setMsg(''); cargar(); }
    catch (err) { setMsg(err.message); }
  };
  const toggle = async (u) => {
    try { await api(`/usuarios/${u.id}/activo`, { method: 'PATCH', body: { activo: !u.activo } }); cargar(); }
    catch (err) { setMsg(err.message); }
  };
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  return (
    <>
      <h4>Gestión de usuarios</h4>
      {msg && <div className="alert alert-danger py-2">{msg}</div>}
      <form onSubmit={crear} className="row g-2 mb-3">
        <div className="col-md"><input className="form-control" placeholder="Nombre completo" required value={f.nombre} onChange={set('nombre')} /></div>
        <div className="col-md"><input className="form-control" placeholder="Usuario" required value={f.username} onChange={set('username')} /></div>
        <div className="col-md"><input className="form-control" type="email" placeholder="Correo" value={f.email} onChange={set('email')} /></div>
        <div className="col-md"><input className="form-control" type="password" placeholder="Contraseña" required value={f.password} onChange={set('password')} /></div>
        <div className="col-md">
          <select className="form-select" value={f.rol} onChange={set('rol')}>
            <option value="ADMIN">Administrador</option><option value="MESERO">Mesero</option><option value="COCINA">Cocina</option>
          </select>
        </div>
        <div className="col-auto"><button className="btn btn-primary">Registrar</button></div>
      </form>
      <table className="table table-sm table-striped">
        <thead><tr><th>Nombre</th><th>Usuario</th><th>Correo</th><th>Rol</th><th>Estado</th><th></th></tr></thead>
        <tbody>
          {list.map((u) => (
            <tr key={u.id}>
              <td>{u.nombre}</td><td>{u.username}</td><td>{u.email}</td><td>{u.rol}</td>
              <td>{u.activo ? 'Activo' : 'Inactivo'}</td>
              <td><button className="btn btn-sm btn-outline-secondary" onClick={() => toggle(u)}>{u.activo ? 'Desactivar' : 'Activar'}</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
