<?php
namespace Sigper\Services;

use Sigper\Exceptions\AuthenticationException;
use Sigper\Exceptions\ForbiddenException;
use Sigper\Repositories\UserRepository;
use Sigper\Security\JwtService;
use Sigper\Security\PasswordHasher;

final class AuthService
{
    public function __construct(private UserRepository $users, private PasswordHasher $hasher, private JwtService $jwt)
    {
    }

    public function login(string $identifier, string $password): array
    {
        $u = $this->users->findByIdentifier($identifier);
        if (!$u || !$this->hasher->verify($password, $u['password_hash'])) {
            throw new AuthenticationException('Credenciales incorrectas');
        }
        if (!$u['activo']) {
            throw new ForbiddenException('Usuario inactivo');
        }
        $user = ['id' => (int) $u['id'], 'nombre' => $u['nombre'], 'rol' => $u['rol']];
        return ['token' => $this->jwt->issue($user), 'user' => $user];
    }
}
