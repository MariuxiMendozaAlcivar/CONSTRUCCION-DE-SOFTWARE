<?php
namespace Sigper\Controllers;

use Sigper\Core\Request;
use Sigper\Core\Response;
use Sigper\Services\OrderService;

final class OrderController
{
    public function __construct(private OrderService $orders)
    {
    }

    public function store(Request $r): Response
    {
        return Response::json(['id' => $this->orders->create($r->user, $r->body)], 201);
    }

    public function modify(Request $r, array $p): Response
    {
        $this->orders->modify((int) $p['id'], $r->body);
        return Response::json(['ok' => true]);
    }

    public function index(Request $r): Response
    {
        return Response::json($this->orders->search($r->query));
    }

    public function summary(Request $r): Response
    {
        return Response::json($this->orders->summary());
    }

    public function show(Request $r, array $p): Response
    {
        return Response::json($this->orders->detail((int) $p['id']));
    }

    public function changeStatus(Request $r, array $p): Response
    {
        $this->orders->changeStatus((int) $p['id'], (string) ($r->body['estado'] ?? ''), $r->user);
        return Response::json(['ok' => true]);
    }
}
