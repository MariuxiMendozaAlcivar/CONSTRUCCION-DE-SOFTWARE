<?php
namespace Sigper\Tests;

use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;
use Sigper\Domain\OrderStateMachine;
use Sigper\Domain\OrderStatus as S;
use Sigper\Exceptions\ConflictException;
use Sigper\Exceptions\ForbiddenException;

final class OrderStateMachineTest extends TestCase
{
    #[DataProvider('transicionesValidas')]
    public function testTransicionesValidas(S $from, S $to, string $rol): void
    {
        (new OrderStateMachine())->assertTransition($from, $to, $rol);
        $this->addToAssertionCount(1);
    }

    public static function transicionesValidas(): array
    {
        return [
            [S::Pendiente, S::EnPreparacion, 'COCINA'],
            [S::EnPreparacion, S::Listo, 'COCINA'],
            [S::Listo, S::Entregado, 'MESERO'],
            [S::Pendiente, S::Cancelado, 'MESERO'],
            [S::Listo, S::Entregado, 'ADMIN'],
        ];
    }

    #[DataProvider('transicionesProhibidas')]
    public function testTransicionesProhibidas(S $from, S $to, string $rol): void
    {
        $this->expectException(ConflictException::class);
        (new OrderStateMachine())->assertTransition($from, $to, $rol);
    }

    public static function transicionesProhibidas(): array
    {
        return [
            [S::Entregado, S::EnPreparacion, 'ADMIN'],   // RN-12
            [S::Pendiente, S::Entregado, 'MESERO'],      // salta estados
            [S::Cancelado, S::Pendiente, 'ADMIN'],
        ];
    }

    public function testRolNoAutorizado(): void
    {
        $this->expectException(ForbiddenException::class);
        (new OrderStateMachine())->assertTransition(S::Pendiente, S::EnPreparacion, 'MESERO');
    }
}
