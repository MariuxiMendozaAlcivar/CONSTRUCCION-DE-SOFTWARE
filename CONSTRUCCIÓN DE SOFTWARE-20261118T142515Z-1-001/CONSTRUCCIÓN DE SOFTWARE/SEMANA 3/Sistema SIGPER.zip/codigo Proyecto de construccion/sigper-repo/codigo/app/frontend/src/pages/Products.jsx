import { useEffect, useState } from 'react';
import { api } from '../api.js';

const vacio = { id: null, codigo: '', nombre: '', descripcion: '', precio: '', categoria_id: '', imagen_url: '', activo: 1 };

export default function Products() {
  const [list, setList] = useState([]);
  const [cats, setCats] = useState([]);
  const [f, setF] = useState(vacio);
  const [msg, setMsg] = useState('');
  const cargar = () => api('/productos').then(setList);
  useEffect(() => { cargar(); api('/categorias?activas=1').then(setCats); }, []);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const guardar = async (e) => {
    e.preventDefault();
    try {
      await api(f.id ? `/productos/${f.id}` : '/productos', { method: f.id ? 'PUT' : 'POST', body: f });
      setF(vacio); setMsg(''); cargar();
    } catch (err) { setMsg(err.message); }
  };
  const toggle = async (p) => { await api(`/productos/${p.id}`, { method: 'PUT', body: { ...p, activo: !p.activo } }); cargar(); };

  return (
    <>
      <h4>Productos del menú</h4>
      {msg && <div className="alert alert-danger py-2">{msg}</div>}
      <form onSubmit={guardar} className="row g-2 mb-3">
        <div className="col-md-1"><input className="form-control" placeholder="Código" required value={f.codigo} onChange={set('codigo')} /></div>
        <div className="col-md-2"><input className="form-control" placeholder="Nombre" required value={f.nombre} onChange={set('nombre')} /></div>
        <div className="col-md-3"><input className="form-control" placeholder="Descripción" value={f.descripcion} onChange={set('descripcion')} /></div>
        <div className="col-md-1"><input className="form-control" type="number" step="0.01" min="0.01" placeholder="Precio" required value={f.precio} onChange={set('precio')} /></div>
        <div className="col-md-2">
          <select className="form-select" required value={f.categoria_id} onChange={set('categoria_id')}>
            <option value="">Categoría...</option>
            {cats.map((c) => <option key={c.id} value={c.id}>{c.nombre}</option>)}
          </select>
        </div>
        <div className="col-md-2"><input className="form-control" placeholder="URL imagen (opcional)" value={f.imagen_url || ''} onChange={set('imagen_url')} /></div>
        <div className="col-auto">
          <button className="btn btn-primary">{f.id ? 'Actualizar' : 'Agregar'}</button>
          {f.id && <button type="button" className="btn btn-link" onClick={() => setF(vacio)}>Cancelar</button>}
        </div>
      </form>
      <table className="table table-sm table-striped">
        <thead><tr><th>Código</th><th>Nombre</th><th>Categoría</th><th>Precio</th><th>Estado</th><th></th></tr></thead>
        <tbody>
          {list.map((p) => (
            <tr key={p.id}>
              <td>{p.codigo}</td><td>{p.nombre}</td><td>{p.categoria}</td><td>${Number(p.precio).toFixed(2)}</td>
              <td>{p.activo ? 'Disponible' : 'No disponible'}</td>
              <td>
                <button className="btn btn-sm btn-outline-primary me-1" onClick={() => setF({ ...p })}>Editar</button>
                <button className="btn btn-sm btn-outline-secondary" onClick={() => toggle(p)}>{p.activo ? 'Desactivar' : 'Activar'}</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
