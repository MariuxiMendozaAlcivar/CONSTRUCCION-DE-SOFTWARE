import { useEffect, useState } from 'react';
import { api } from '../api.js';

export default function Categories() {
  const [list, setList] = useState([]);
  const [f, setF] = useState({ nombre: '', descripcion: '' });
  const [msg, setMsg] = useState('');
  const cargar = () => api('/categorias').then(setList);
  useEffect(() => { cargar(); }, []);

  const crear = async (e) => {
    e.preventDefault();
    try { await api('/categorias', { method: 'POST', body: f }); setF({ nombre: '', descripcion: '' }); setMsg(''); cargar(); }
    catch (err) { setMsg(err.message); }
  };
  const toggle = async (c) => {
    await api(`/categorias/${c.id}`, { method: 'PUT', body: { ...c, activo: !c.activo } });
    cargar();
  };

  return (
    <>
      <h4>Categorías del menú</h4>
      {msg && <div className="alert alert-danger py-2">{msg}</div>}
      <form onSubmit={crear} className="row g-2 mb-3">
        <div className="col-md-3"><input className="form-control" placeholder="Nombre" required value={f.nombre} onChange={(e) => setF({ ...f, nombre: e.target.value })} /></div>
        <div className="col-md-6"><input className="form-control" placeholder="Descripción (opcional)" value={f.descripcion} onChange={(e) => setF({ ...f, descripcion: e.target.value })} /></div>
        <div className="col-auto"><button className="btn btn-primary">Agregar</button></div>
      </form>
      <table className="table table-sm table-striped">
        <thead><tr><th>Nombre</th><th>Descripción</th><th>Estado</th><th></th></tr></thead>
        <tbody>
          {list.map((c) => (
            <tr key={c.id}>
              <td>{c.nombre}</td><td>{c.descripcion}</td><td>{c.activo ? 'Activa' : 'Inactiva'}</td>
              <td><button className="btn btn-sm btn-outline-secondary" onClick={() => toggle(c)}>{c.activo ? 'Desactivar' : 'Activar'}</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
