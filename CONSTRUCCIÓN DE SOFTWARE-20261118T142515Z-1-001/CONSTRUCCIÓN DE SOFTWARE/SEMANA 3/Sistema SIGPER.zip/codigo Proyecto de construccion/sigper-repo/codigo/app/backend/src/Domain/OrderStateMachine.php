<?php
namespace Sigper\Domain;

use Sigper\Exceptions\ConflictException;
use Sigper\Exceptions\ForbiddenException;

/** RN-11 / RN-12: flujo de estados permitido y qué rol puede aplicar cada cambio. */
final class OrderStateMachine
{
    private const FLOW = [
        'Pendiente' => ['En preparación', 'Cancelado'],
        'En preparación' => ['Listo', 'Cancelado'],
        'Listo' => ['Entregado', 'Cancelado'],
    ];
    private const WHO = [
        'En preparación' => ['COCINA', 'ADMIN'],
        'Listo' => ['COCINA', 'ADMIN'],
        'Entregado' => ['MESERO', 'ADMIN'],
        'Cancelado' => ['MESERO', 'ADMIN'],
    ];

    public function assertTransition(OrderStatus $from, OrderStatus $to, string $role): void
    {
        if (!in_array($to->value, self::FLOW[$from->value] ?? [], true)) {
            throw new ConflictException("No se puede pasar de \"{$from->value}\" a \"{$to->value}\"");
        }
        if (!in_array($role, self::WHO[$to->value], true)) {
            throw new ForbiddenException('Su rol no puede aplicar este estado');
        }
    }
}
