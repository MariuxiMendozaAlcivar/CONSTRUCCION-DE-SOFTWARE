<?php
namespace Sigper\Core;

use Sigper\Exceptions\AuthenticationException;
use Sigper\Exceptions\ForbiddenException;
use Sigper\Security\JwtService;

/** Autentica el token y verifica el rol (RF-04). Lista vacía = cualquier usuario autenticado. */
final class AuthGuard
{
    public function __construct(private JwtService $jwt)
    {
    }

    public function check(Request $request, array $roles): void
    {
        $token = $request->bearer();
        if ($token === '') {
            throw new AuthenticationException();
        }
        $request->user = $this->jwt->verify($token);
        if ($roles && !in_array($request->user['rol'] ?? '', $roles, true)) {
            throw new ForbiddenException();
        }
    }
}
