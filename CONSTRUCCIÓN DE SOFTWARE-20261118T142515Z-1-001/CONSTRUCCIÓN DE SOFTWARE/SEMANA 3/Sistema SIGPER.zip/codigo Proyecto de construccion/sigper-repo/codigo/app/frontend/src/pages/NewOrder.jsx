import { useEffect, useState } from 'react';
import { api } from '../api.js';

export default function NewOrder() {
  const [productos, setProductos] = useState([]);
  const [carrito, setCarrito] = useState([]); // {producto, cantidad, observaciones}
  const [tipo, setTipo] = useState('MESA');
  const [mesa, setMesa] = useState('');
  const [msg, setMsg] = useState(null);

  useEffect(() => { api('/productos?disponibles=1').then(setProductos); }, []);

  const agregar = (p) => setCarrito((c) => {
    const ex = c.find((i) => i.producto.id === p.id);
    return ex ? c.map((i) => (i === ex ? { ...i, cantidad: i.cantidad + 1 } : i)) : [...c, { producto: p, cantidad: 1, observaciones: '' }];
  });
  const cambiar = (id, campo, valor) => setCarrito((c) => c.map((i) => (i.producto.id === id ? { ...i, [campo]: valor } : i)));
  const quitar = (id) => setCarrito((c) => c.filter((i) => i.producto.id !== id));
  const total = carrito.reduce((s, i) => s + i.producto.precio * i.cantidad, 0);

  const guardar = async () => {
    try {
      const r = await api('/pedidos', {
        method: 'POST',
        body: { tipo, mesa, items: carrito.map((i) => ({ producto_id: i.producto.id, cantidad: i.cantidad, observaciones: i.observaciones })) },
      });
      setMsg({ ok: true, t: `Pedido #${r.id} registrado` }); setCarrito([]); setMesa('');
    } catch (e) { setMsg({ ok: false, t: e.message }); }
  };

  const porCategoria = productos.reduce((acc, p) => ((acc[p.categoria] ||= []).push(p), acc), {});

  return (
    <div className="row">
      <div className="col-md-7">
        <h4>Menú</h4>
        {Object.entries(porCategoria).map(([cat, ps]) => (
          <div key={cat} className="mb-3">
            <h6 className="text-muted">{cat}</h6>
            <div className="d-flex flex-wrap gap-2">
              {ps.map((p) => (
                <button key={p.id} className="btn btn-outline-dark text-start" onClick={() => agregar(p)} title={p.descripcion}>
                  <div>{p.nombre}</div><small>${Number(p.precio).toFixed(2)}</small>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div className="col-md-5">
        <h4>Pedido</h4>
        {msg && <div className={`alert py-2 alert-${msg.ok ? 'success' : 'danger'}`}>{msg.t}</div>}
        <div className="d-flex gap-2 mb-2">
          <select className="form-select" value={tipo} onChange={(e) => setTipo(e.target.value)}>
            <option value="MESA">Por mesa</option><option value="LLEVAR">Para llevar</option>
          </select>
          {tipo === 'MESA' && <input className="form-control" placeholder="N.º de mesa" value={mesa} onChange={(e) => setMesa(e.target.value)} />}
        </div>
        {carrito.map((i) => (
          <div key={i.producto.id} className="border rounded p-2 mb-2">
            <div className="d-flex align-items-center gap-2">
              <strong className="flex-grow-1">{i.producto.nombre}</strong>
              <input type="number" min="1" className="form-control form-control-sm" style={{ width: 70 }}
                value={i.cantidad} onChange={(e) => cambiar(i.producto.id, 'cantidad', Math.max(1, +e.target.value || 1))} />
              <span>${(i.producto.precio * i.cantidad).toFixed(2)}</span>
              <button className="btn btn-sm btn-outline-danger" onClick={() => quitar(i.producto.id)}>×</button>
            </div>
            <input className="form-control form-control-sm mt-1" placeholder="Observaciones"
              value={i.observaciones} onChange={(e) => cambiar(i.producto.id, 'observaciones', e.target.value)} />
          </div>
        ))}
        <h5 className="text-end">Total: ${total.toFixed(2)}</h5>
        <button className="btn btn-success w-100" disabled={!carrito.length} onClick={guardar}>Registrar pedido</button>
      </div>
    </div>
  );
}
