import { useState } from 'react';
import { api } from '../api.js';

export default function Login({ onLogin }) {
  const [f, setF] = useState({ identificador: '', password: '' });
  const [error, setError] = useState('');

  const enviar = async (e) => {
    e.preventDefault();
    try { onLogin(await api('/auth/login', { method: 'POST', body: f })); }
    catch (err) { setError(err.message); }
  };

  return (
    <div className="container" style={{ maxWidth: 380, marginTop: 100 }}>
      <h3 className="text-center mb-3">SIGPER</h3>
      <form onSubmit={enviar} className="card card-body">
        {error && <div className="alert alert-danger py-2">{error}</div>}
        <input className="form-control mb-2" placeholder="Usuario o correo" required
          value={f.identificador} onChange={(e) => setF({ ...f, identificador: e.target.value })} />
        <input className="form-control mb-3" type="password" placeholder="Contraseña" required
          value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
        <button className="btn btn-primary">Iniciar sesión</button>
      </form>
    </div>
  );
}
