<?php
namespace Sigper\Repositories;

use PDO;
use Sigper\Core\Database;
use Sigper\Exceptions\ConflictException;

final class PdoOrderRepository implements OrderRepositoryInterface
{
    private const DT = "DATE_FORMAT(%s,'%%Y-%%m-%%dT%%H:%%i:%%s')";
    private const COLS = 'p.id, p.usuario_id, p.tipo, p.mesa, p.estado, p.total, u.nombre AS responsable';

    public function __construct(private Database $db)
    {
    }

    private function cols(): string
    {
        return self::COLS . ', ' . sprintf(self::DT, 'p.fecha') . ' AS fecha';
    }

    /** Ejecuta $fn dentro de una transacción; si falla hace rollback (integridad de datos). */
    private function transaction(callable $fn): mixed
    {
        $pdo = $this->db->pdo();
        $pdo->beginTransaction();
        try {
            $result = $fn($pdo);
            $pdo->commit();
            return $result;
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    private function insertLines(PDO $pdo, int $orderId, array $lines): void
    {
        $st = $pdo->prepare('INSERT INTO pedido_detalle (pedido_id,producto_id,cantidad,precio_unitario,subtotal,observaciones) VALUES (?,?,?,?,?,?)');
        foreach ($lines as $l) {
            $st->execute([$orderId, $l['producto_id'], $l['cantidad'], $l['precio_unitario'], $l['subtotal'], $l['observaciones']]);
        }
    }

    private function log(PDO $pdo, int $orderId, ?string $from, string $to, int $userId): void
    {
        $pdo->prepare('INSERT INTO historial_estados (pedido_id,estado_anterior,estado_nuevo,usuario_id) VALUES (?,?,?,?)')
            ->execute([$orderId, $from, $to, $userId]);
    }

    public function create(int $userId, string $tipo, ?string $mesa, array $lines, float $total): int
    {
        return $this->transaction(function (PDO $pdo) use ($userId, $tipo, $mesa, $lines, $total) {
            $pdo->prepare('INSERT INTO pedidos (usuario_id,tipo,mesa,total) VALUES (?,?,?,?)')->execute([$userId, $tipo, $mesa, $total]);
            $id = (int) $pdo->lastInsertId();
            $this->insertLines($pdo, $id, $lines);
            $this->log($pdo, $id, null, 'Pendiente', $userId);
            return $id;
        });
    }

    public function find(int $id): ?array
    {
        $st = $this->db->pdo()->prepare('SELECT id, estado FROM pedidos WHERE id=?');
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }

    private function items(array $orderIds): array
    {
        $in = implode(',', array_fill(0, count($orderIds), '?'));
        $st = $this->db->pdo()->prepare(
            "SELECT d.id, d.pedido_id, d.cantidad, d.precio_unitario, d.subtotal, d.observaciones, pr.nombre
             FROM pedido_detalle d JOIN productos pr ON pr.id=d.producto_id WHERE d.pedido_id IN ($in) ORDER BY d.id");
        $st->execute($orderIds);
        return array_map(fn(array $i) => ['precio_unitario' => (float) $i['precio_unitario'], 'subtotal' => (float) $i['subtotal']] + $i, $st->fetchAll());
    }

    public function details(int $id): ?array
    {
        $st = $this->db->pdo()->prepare('SELECT ' . $this->cols() . ' FROM pedidos p JOIN usuarios u ON u.id=p.usuario_id WHERE p.id=?');
        $st->execute([$id]);
        $order = $st->fetch();
        if (!$order) {
            return null;
        }
        $order['total'] = (float) $order['total'];
        $order['items'] = $this->items([$id]);
        $h = $this->db->pdo()->prepare(
            'SELECT h.estado_anterior, h.estado_nuevo, ' . sprintf(self::DT, 'h.fecha') . ' AS fecha, u.nombre AS usuario
             FROM historial_estados h JOIN usuarios u ON u.id=h.usuario_id WHERE h.pedido_id=? ORDER BY h.id');
        $h->execute([$id]);
        $order['historial'] = $h->fetchAll();
        return $order;
    }

    public function search(array $f): array
    {
        $sql = 'SELECT ' . $this->cols() . ' FROM pedidos p JOIN usuarios u ON u.id=p.usuario_id WHERE 1=1';
        $params = [];
        if (!empty($f['estado'])) {
            $states = explode(',', $f['estado']);
            $sql .= ' AND p.estado IN (' . implode(',', array_fill(0, count($states), '?')) . ')';
            $params = array_merge($params, $states);
        }
        if (!empty($f['fecha'])) {
            $sql .= ' AND DATE(p.fecha)=?';
            $params[] = $f['fecha'];
        }
        if (!empty($f['tipo'])) {
            $sql .= ' AND p.tipo=?';
            $params[] = $f['tipo'];
        }
        if (!empty($f['q'])) {
            $sql .= ' AND p.id=?';
            $params[] = (int) $f['q'];
        }
        $st = $this->db->pdo()->prepare($sql . ' ORDER BY p.fecha DESC, p.id DESC LIMIT 200');
        $st->execute($params);
        $orders = array_map(fn(array $o) => ['total' => (float) $o['total']] + $o, $st->fetchAll());
        if (!empty($f['detalle']) && $orders) {
            $items = $this->items(array_column($orders, 'id'));
            foreach ($orders as &$o) {
                $o['items'] = array_values(array_filter($items, fn($i) => (int) $i['pedido_id'] === (int) $o['id']));
            }
        }
        return $orders;
    }

    public function replaceItems(int $id, array $lines, float $total): void
    {
        $this->transaction(function (PDO $pdo) use ($id, $lines, $total) {
            $pdo->prepare('DELETE FROM pedido_detalle WHERE pedido_id=?')->execute([$id]);
            $this->insertLines($pdo, $id, $lines);
            $pdo->prepare('UPDATE pedidos SET total=? WHERE id=?')->execute([$total, $id]);
        });
    }

    public function updateStatus(int $id, string $from, string $to, int $userId): void
    {
        $this->transaction(function (PDO $pdo) use ($id, $from, $to, $userId) {
            // Control de concurrencia: solo actualiza si el estado sigue siendo el que se leyó.
            $st = $pdo->prepare('UPDATE pedidos SET estado=? WHERE id=? AND estado=?');
            $st->execute([$to, $id, $from]);
            if ($st->rowCount() === 0) {
                throw new ConflictException('El pedido cambió de estado, actualice la pantalla');
            }
            $this->log($pdo, $id, $from, $to, $userId);
        });
    }

    public function summary(): array
    {
        return array_map(fn($r) => ['estado' => $r['estado'], 'n' => (int) $r['n']],
            $this->db->pdo()->query('SELECT estado, COUNT(*) AS n FROM pedidos GROUP BY estado')->fetchAll());
    }
}
