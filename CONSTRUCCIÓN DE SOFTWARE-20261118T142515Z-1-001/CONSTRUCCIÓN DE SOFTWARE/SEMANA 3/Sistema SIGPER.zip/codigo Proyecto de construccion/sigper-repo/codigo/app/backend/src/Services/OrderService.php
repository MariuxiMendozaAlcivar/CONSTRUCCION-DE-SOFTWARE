<?php
namespace Sigper\Services;

use Sigper\Domain\OrderCalculator;
use Sigper\Domain\OrderStateMachine;
use Sigper\Domain\OrderStatus;
use Sigper\Exceptions\ConflictException;
use Sigper\Exceptions\NotFoundException;
use Sigper\Exceptions\ValidationException;
use Sigper\Repositories\OrderRepositoryInterface;
use Sigper\Repositories\ProductCatalogInterface;

/** Casos de uso de pedidos. Depende de abstracciones (DIP), no de PDO. */
final class OrderService
{
    public function __construct(
        private OrderRepositoryInterface $orders,
        private ProductCatalogInterface $catalog,
        private OrderCalculator $calculator,
        private OrderStateMachine $stateMachine
    ) {
    }

    public function create(array $user, array $data): int
    {
        $tipo = $data['tipo'] ?? '';
        if (!in_array($tipo, ['MESA', 'LLEVAR'], true)) {
            throw new ValidationException('Tipo de pedido inválido');
        }
        $mesa = trim((string) ($data['mesa'] ?? ''));
        if ($tipo === 'MESA' && $mesa === '') {
            throw new ValidationException('Indique el número de mesa');
        }
        $priced = $this->price($data['items'] ?? []);
        return $this->orders->create((int) $user['id'], $tipo, $tipo === 'MESA' ? $mesa : null, $priced['lines'], $priced['total']);
    }

    public function modify(int $id, array $data): void
    {
        $order = $this->orders->find($id) ?? throw new NotFoundException('Pedido no encontrado');
        if (!OrderStatus::from($order['estado'])->isModifiable()) {
            throw new ConflictException('El pedido ya no admite cambios');
        }
        $priced = $this->price($data['items'] ?? []);
        $this->orders->replaceItems($id, $priced['lines'], $priced['total']);
    }

    public function changeStatus(int $id, string $target, array $user): void
    {
        $order = $this->orders->find($id) ?? throw new NotFoundException('Pedido no encontrado');
        $to = OrderStatus::tryFrom($target) ?? throw new ValidationException('Estado inválido');
        $this->stateMachine->assertTransition(OrderStatus::from($order['estado']), $to, (string) $user['rol']);
        $this->orders->updateStatus($id, $order['estado'], $to->value, (int) $user['id']);
    }

    public function detail(int $id): array
    {
        return $this->orders->details($id) ?? throw new NotFoundException('Pedido no encontrado');
    }

    public function search(array $filters): array
    {
        return $this->orders->search($filters);
    }

    public function summary(): array
    {
        return $this->orders->summary();
    }

    private function price(mixed $items): array
    {
        if (!is_array($items)) {
            throw new ValidationException('El pedido debe tener al menos un producto');
        }
        $items = array_values(array_filter($items, 'is_array'));
        $ids = array_map(fn($i) => (int) ($i['producto_id'] ?? 0), $items);
        return $this->calculator->build($items, $this->catalog->findActiveByIds($ids));
    }
}
