<?php
namespace Sigper\Repositories;

/** Interfaz mínima que necesita OrderService (Principio de Segregación de Interfaces). */
interface ProductCatalogInterface
{
    /** @return array productos activos indexados por id */
    public function findActiveByIds(array $ids): array;
}
