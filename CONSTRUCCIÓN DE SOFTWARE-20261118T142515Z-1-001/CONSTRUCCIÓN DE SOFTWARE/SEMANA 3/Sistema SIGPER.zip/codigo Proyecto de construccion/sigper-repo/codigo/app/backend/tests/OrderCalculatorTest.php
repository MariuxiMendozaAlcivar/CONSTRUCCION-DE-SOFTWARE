<?php
namespace Sigper\Tests;

use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;
use Sigper\Domain\OrderCalculator;
use Sigper\Exceptions\ValidationException;

final class OrderCalculatorTest extends TestCase
{
    private array $products = [1 => ['id' => 1, 'precio' => '2.50'], 2 => ['id' => 2, 'precio' => '5.00']];

    public function testCalculaSubtotalesYTotal(): void
    {
        $r = (new OrderCalculator())->build([
            ['producto_id' => 1, 'cantidad' => 2],
            ['producto_id' => 2, 'cantidad' => 1, 'observaciones' => ' sin cebolla '],
        ], $this->products);

        $this->assertSame(5.0, $r['lines'][0]['subtotal']);
        $this->assertSame(10.0, $r['total']);
        $this->assertSame('sin cebolla', $r['lines'][1]['observaciones']);
    }

    public function testPedidoSinProductosLanzaExcepcion(): void
    {
        $this->expectException(ValidationException::class);
        (new OrderCalculator())->build([], $this->products);
    }

    public function testProductoNoDisponibleLanzaExcepcion(): void
    {
        $this->expectException(ValidationException::class);
        (new OrderCalculator())->build([['producto_id' => 99, 'cantidad' => 1]], $this->products);
    }

    #[DataProvider('cantidadesInvalidas')]
    public function testCantidadesInvalidas(mixed $qty): void
    {
        $this->expectException(ValidationException::class);
        (new OrderCalculator())->build([['producto_id' => 1, 'cantidad' => $qty]], $this->products);
    }

    public static function cantidadesInvalidas(): array
    {
        return [[0], [-3], ['abc'], [1.5], [null]];
    }
}
