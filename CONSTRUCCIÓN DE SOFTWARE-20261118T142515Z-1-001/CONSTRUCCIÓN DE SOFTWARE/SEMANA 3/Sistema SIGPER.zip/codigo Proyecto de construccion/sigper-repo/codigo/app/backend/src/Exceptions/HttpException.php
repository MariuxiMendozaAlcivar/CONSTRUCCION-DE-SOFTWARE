<?php
namespace Sigper\Exceptions;

/** Excepción base: lleva el código HTTP que se devolverá al cliente. */
class HttpException extends \RuntimeException
{
    public function __construct(string $message, private int $status = 500)
    {
        parent::__construct($message);
    }

    public function status(): int
    {
        return $this->status;
    }
}
