<?php
namespace Sigper\Exceptions;

final class ForbiddenException extends HttpException
{
    public function __construct(string $message = 'Sin permisos')
    {
        parent::__construct($message, 403);
    }
}
