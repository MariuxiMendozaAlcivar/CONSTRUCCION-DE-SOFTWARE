<?php
namespace Sigper\Domain;

enum OrderStatus: string
{
    case Pendiente = 'Pendiente';
    case EnPreparacion = 'En preparación';
    case Listo = 'Listo';
    case Entregado = 'Entregado';
    case Cancelado = 'Cancelado';

    /** RF-09: solo se pueden modificar pedidos que aún no están listos. */
    public function isModifiable(): bool
    {
        return $this === self::Pendiente || $this === self::EnPreparacion;
    }
}
