import { useEffect, useState } from 'react';
import { api } from '../api.js';

export default function Kitchen() {
  const [pedidos, setPedidos] = useState([]);
  const [msg, setMsg] = useState('');

  const cargar = () => api('/pedidos?detalle=1&estado=Pendiente,En preparación').then((d) => setPedidos([...d].reverse()));
  useEffect(() => { cargar(); const t = setInterval(cargar, 10000); return () => clearInterval(t); }, []);

  const cambiar = async (id, estado) => {
    try { await api(`/pedidos/${id}/estado`, { method: 'PATCH', body: { estado } }); setMsg(''); cargar(); }
    catch (e) { setMsg(e.message); }
  };

  return (
    <>
      <h4>Panel de cocina <small className="text-muted fs-6">(se actualiza cada 10 s)</small></h4>
      {msg && <div className="alert alert-danger py-2">{msg}</div>}
      {!pedidos.length && <p className="text-muted">No hay pedidos pendientes.</p>}
      <div className="row g-3">
        {pedidos.map((p) => (
          <div key={p.id} className="col-md-4">
            <div className={`card border-${p.estado === 'Pendiente' ? 'warning' : 'primary'} border-2`}>
              <div className="card-header d-flex justify-content-between">
                <strong>#{p.id} — {p.tipo === 'MESA' ? `Mesa ${p.mesa}` : 'Para llevar'}</strong>
                <span>{new Date(p.fecha).toLocaleTimeString()}</span>
              </div>
              <ul className="list-group list-group-flush">
                {p.items.map((i) => (
                  <li key={i.id} className="list-group-item">
                    <strong>{i.cantidad} ×</strong> {i.nombre}
                    {i.observaciones && <div className="text-danger small">⚠ {i.observaciones}</div>}
                  </li>
                ))}
              </ul>
              <div className="card-footer">
                {p.estado === 'Pendiente'
                  ? <button className="btn btn-warning w-100" onClick={() => cambiar(p.id, 'En preparación')}>Iniciar preparación</button>
                  : <button className="btn btn-success w-100" onClick={() => cambiar(p.id, 'Listo')}>Marcar como listo</button>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
