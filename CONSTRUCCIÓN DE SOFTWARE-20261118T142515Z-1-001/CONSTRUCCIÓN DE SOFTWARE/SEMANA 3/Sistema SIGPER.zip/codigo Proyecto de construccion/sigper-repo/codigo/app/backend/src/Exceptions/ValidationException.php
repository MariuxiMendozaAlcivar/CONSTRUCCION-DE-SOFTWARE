<?php
namespace Sigper\Exceptions;

final class ValidationException extends HttpException
{
    public function __construct(string $message = 'Datos inválidos')
    {
        parent::__construct($message, 422);
    }
}
