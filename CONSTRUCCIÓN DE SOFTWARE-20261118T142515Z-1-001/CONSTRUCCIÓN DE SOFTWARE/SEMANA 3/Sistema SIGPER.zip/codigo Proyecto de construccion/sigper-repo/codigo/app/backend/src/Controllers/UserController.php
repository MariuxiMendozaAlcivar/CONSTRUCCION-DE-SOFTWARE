<?php
namespace Sigper\Controllers;

use Sigper\Core\Request;
use Sigper\Core\Response;
use Sigper\Core\Validator;
use Sigper\Repositories\UserRepository;
use Sigper\Security\PasswordHasher;

final class UserController
{
    private const ROLES = ['ADMIN', 'MESERO', 'COCINA'];

    public function __construct(private UserRepository $users, private PasswordHasher $hasher)
    {
    }

    public function index(Request $r): Response
    {
        return Response::json($this->users->all());
    }

    public function store(Request $r): Response
    {
        $d = $r->body;
        Validator::required($d, ['nombre', 'username', 'password', 'rol']);
        Validator::assert(in_array($d['rol'], self::ROLES, true), 'Rol inválido');
        Validator::assert(strlen((string) $d['password']) >= 8, 'La contraseña debe tener al menos 8 caracteres');
        $id = $this->users->create($d, $this->hasher->hash((string) $d['password']));
        return Response::json(['id' => $id], 201);
    }

    public function update(Request $r, array $p): Response
    {
        $d = $r->body;
        Validator::required($d, ['nombre', 'rol']);
        Validator::assert(in_array($d['rol'], self::ROLES, true), 'Rol inválido');
        $hash = !empty($d['password']) ? $this->hasher->hash((string) $d['password']) : null;
        $this->users->update((int) $p['id'], $d, $hash);
        return Response::json(['ok' => true]);
    }

    public function setActive(Request $r, array $p): Response
    {
        Validator::assert((int) $p['id'] !== (int) $r->user['id'], 'No puede desactivar su propia cuenta');
        $this->users->setActive((int) $p['id'], !empty($r->body['activo']));
        return Response::json(['ok' => true]);
    }
}
