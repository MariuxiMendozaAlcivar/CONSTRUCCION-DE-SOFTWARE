<?php
namespace Sigper\Repositories;

use PDOException;
use Sigper\Core\Database;
use Sigper\Exceptions\ConflictException;

final class CategoryRepository
{
    public function __construct(private Database $db)
    {
    }

    public function all(bool $onlyActive = false): array
    {
        $sql = 'SELECT * FROM categorias' . ($onlyActive ? ' WHERE activo=1' : '') . ' ORDER BY nombre';
        return $this->db->pdo()->query($sql)->fetchAll();
    }

    public function exists(int $id): bool
    {
        $st = $this->db->pdo()->prepare('SELECT 1 FROM categorias WHERE id=?');
        $st->execute([$id]);
        return (bool) $st->fetchColumn();
    }

    public function create(string $nombre, ?string $descripcion): int
    {
        try {
            $this->db->pdo()->prepare('INSERT INTO categorias (nombre,descripcion) VALUES (?,?)')->execute([$nombre, $descripcion]);
            return (int) $this->db->pdo()->lastInsertId();
        } catch (PDOException $e) {
            throw $e->getCode() === '23000' ? new ConflictException('La categoría ya existe') : $e;
        }
    }

    public function update(int $id, string $nombre, ?string $descripcion, bool $activo): void
    {
        try {
            $this->db->pdo()->prepare('UPDATE categorias SET nombre=?, descripcion=?, activo=? WHERE id=?')
                ->execute([$nombre, $descripcion, $activo ? 1 : 0, $id]);
        } catch (PDOException $e) {
            throw $e->getCode() === '23000' ? new ConflictException('Nombre de categoría duplicado') : $e;
        }
    }
}
