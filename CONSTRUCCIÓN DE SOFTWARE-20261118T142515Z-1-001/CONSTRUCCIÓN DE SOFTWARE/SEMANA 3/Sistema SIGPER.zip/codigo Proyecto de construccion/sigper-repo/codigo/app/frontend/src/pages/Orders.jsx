import { useEffect, useState } from 'react';
import { api } from '../api.js';

export const ESTADOS = ['Pendiente', 'En preparación', 'Listo', 'Entregado', 'Cancelado'];

export default function Orders({ user }) {
  const [filtros, setFiltros] = useState({ q: '', estado: '', fecha: '', tipo: '' });
  const [list, setList] = useState([]);
  const [resumen, setResumen] = useState([]);
  const [det, setDet] = useState(null);
  const [msg, setMsg] = useState('');

  const cargar = () => {
    const qs = new URLSearchParams(Object.entries(filtros).filter(([, v]) => v)).toString();
    api('/pedidos?' + qs).then(setList);
    api('/pedidos/resumen').then(setResumen);
  };
  useEffect(cargar, [filtros]);

  const ver = async (id) => setDet(det?.id === id ? null : await api('/pedidos/' + id));
  const cambiar = async (id, estado) => {
    try { await api(`/pedidos/${id}/estado`, { method: 'PATCH', body: { estado } }); setMsg(''); setDet(null); cargar(); }
    catch (e) { setMsg(e.message); }
  };
  const set = (k) => (e) => setFiltros({ ...filtros, [k]: e.target.value });
  const puede = (rol) => user.rol === 'ADMIN' || user.rol === rol;

  return (
    <>
      <h4>Pedidos e historial</h4>
      <div className="mb-2">
        {resumen.map((r) => <span key={r.estado} className="badge bg-secondary me-1">{r.estado}: {r.n}</span>)}
      </div>
      {msg && <div className="alert alert-danger py-2">{msg}</div>}
      <div className="row g-2 mb-3">
        <div className="col-md-2"><input className="form-control" placeholder="N.º de pedido" value={filtros.q} onChange={set('q')} /></div>
        <div className="col-md-2">
          <select className="form-select" value={filtros.estado} onChange={set('estado')}>
            <option value="">Todos los estados</option>{ESTADOS.map((e) => <option key={e}>{e}</option>)}
          </select>
        </div>
        <div className="col-md-2"><input type="date" className="form-control" value={filtros.fecha} onChange={set('fecha')} /></div>
        <div className="col-md-2">
          <select className="form-select" value={filtros.tipo} onChange={set('tipo')}>
            <option value="">Mesa y llevar</option><option value="MESA">Mesa</option><option value="LLEVAR">Para llevar</option>
          </select>
        </div>
      </div>
      <table className="table table-sm table-hover">
        <thead><tr><th>#</th><th>Fecha</th><th>Tipo</th><th>Responsable</th><th>Total</th><th>Estado</th><th></th></tr></thead>
        <tbody>
          {list.map((p) => (
            <>
              <tr key={p.id}>
                <td>{p.id}</td><td>{new Date(p.fecha).toLocaleString()}</td>
                <td>{p.tipo === 'MESA' ? `Mesa ${p.mesa}` : 'Para llevar'}</td><td>{p.responsable}</td>
                <td>${Number(p.total).toFixed(2)}</td><td><span className="badge bg-info text-dark">{p.estado}</span></td>
                <td className="text-nowrap">
                  <button className="btn btn-sm btn-outline-dark me-1" onClick={() => ver(p.id)}>Detalle</button>
                  {p.estado === 'Listo' && puede('MESERO') && user.rol !== 'COCINA' &&
                    <button className="btn btn-sm btn-success me-1" onClick={() => cambiar(p.id, 'Entregado')}>Entregar</button>}
                  {['Pendiente', 'En preparación', 'Listo'].includes(p.estado) && puede('MESERO') && user.rol !== 'COCINA' &&
                    <button className="btn btn-sm btn-outline-danger" onClick={() => cambiar(p.id, 'Cancelado')}>Cancelar</button>}
                </td>
              </tr>
              {det?.id === p.id && (
                <tr key={'d' + p.id}><td colSpan="7" className="bg-light">
                  <ul className="mb-1">
                    {det.items.map((i) => <li key={i.id}>{i.cantidad} × {i.nombre} (${Number(i.precio_unitario).toFixed(2)}) = ${Number(i.subtotal).toFixed(2)}{i.observaciones && ` — ${i.observaciones}`}</li>)}
                  </ul>
                  <small className="text-muted">Historial: {det.historial.map((h) => `${h.estado_nuevo} (${h.usuario}, ${new Date(h.fecha).toLocaleTimeString()})`).join(' → ')}</small>
                </td></tr>
              )}
            </>
          ))}
        </tbody>
      </table>
    </>
  );
}
