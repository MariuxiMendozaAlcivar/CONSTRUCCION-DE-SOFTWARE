<?php
namespace Sigper\Repositories;

interface OrderRepositoryInterface
{
    public function create(int $userId, string $tipo, ?string $mesa, array $lines, float $total): int;
    public function find(int $id): ?array;
    public function details(int $id): ?array;
    public function search(array $filters): array;
    public function replaceItems(int $id, array $lines, float $total): void;
    public function updateStatus(int $id, string $from, string $to, int $userId): void;
    public function summary(): array;
}
