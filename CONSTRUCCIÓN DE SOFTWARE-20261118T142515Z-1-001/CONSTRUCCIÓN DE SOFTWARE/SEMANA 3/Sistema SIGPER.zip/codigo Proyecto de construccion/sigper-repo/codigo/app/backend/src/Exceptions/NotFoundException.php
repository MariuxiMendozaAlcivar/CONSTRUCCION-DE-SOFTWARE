<?php
namespace Sigper\Exceptions;

final class NotFoundException extends HttpException
{
    public function __construct(string $message = 'No encontrado')
    {
        parent::__construct($message, 404);
    }
}
