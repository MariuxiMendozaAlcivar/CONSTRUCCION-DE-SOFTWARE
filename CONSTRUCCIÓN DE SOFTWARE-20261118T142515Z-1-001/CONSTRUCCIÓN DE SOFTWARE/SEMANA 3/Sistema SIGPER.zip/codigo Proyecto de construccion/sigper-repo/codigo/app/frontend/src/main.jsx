import React from 'react';
import ReactDOM from 'react-dom/client';
import { HashRouter } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import App from './App.jsx';

// HashRouter: GitHub Pages no puede reescribir rutas, por eso se usa /#/ruta.
ReactDOM.createRoot(document.getElementById('root')).render(
  <HashRouter><App /></HashRouter>
);
