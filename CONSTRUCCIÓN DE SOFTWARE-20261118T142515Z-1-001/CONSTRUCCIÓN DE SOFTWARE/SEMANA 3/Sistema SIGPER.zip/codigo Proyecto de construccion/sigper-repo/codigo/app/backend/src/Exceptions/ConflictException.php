<?php
namespace Sigper\Exceptions;

final class ConflictException extends HttpException
{
    public function __construct(string $message = 'Conflicto con el estado actual')
    {
        parent::__construct($message, 409);
    }
}
