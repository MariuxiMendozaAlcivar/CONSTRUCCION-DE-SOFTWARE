<?php
// Define el espacio de nombres para las clases del núcleo (Core) del backend.
namespace Sigper\Core;

// Importa la excepción lanzada cuando no se cumple una regla de validación.
use Sigper\Exceptions\ValidationException;

// Utilidad estática para validar campos obligatorios y condiciones de negocio/entrada.
final class Validator
{
    // Verifica que cada campo indicado exista en $data y no esté vacío tras recortar espacios.
    public static function required(array $data, array $fields): void
    {
        // Recorre la lista de nombres de campos requeridos.
        foreach ($fields as $f) {
            // Comprueba si la clave no está definida o si su valor convertido a string y recortado es vacío.
            if (!isset($data[$f]) || trim((string) $data[$f]) === '') {
                throw new ValidationException("El campo '$f' es obligatorio");
            }
        }
    }

    // Evalúa una condición booleana y lanza ValidationException con el mensaje dado si es falsa.
    public static function assert(bool $condition, string $message): void
    {
        if (!$condition) {
            throw new ValidationException($message);
        }
    }
}