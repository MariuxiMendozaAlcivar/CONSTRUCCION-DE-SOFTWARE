import { useState } from 'react';
import { Routes, Route, Navigate, NavLink, useNavigate } from 'react-router-dom';
import Login from './pages/Login.jsx';
import Users from './pages/Users.jsx';
import Categories from './pages/Categories.jsx';
import Products from './pages/Products.jsx';
import NewOrder from './pages/NewOrder.jsx';
import Orders from './pages/Orders.jsx';
import Kitchen from './pages/Kitchen.jsx';

// Menú y rutas permitidas por rol (RF-04)
const MENU = {
  ADMIN: [['/usuarios', 'Usuarios'], ['/categorias', 'Categorías'], ['/productos', 'Productos'], ['/pedidos', 'Pedidos']],
  MESERO: [['/nuevo', 'Nuevo pedido'], ['/pedidos', 'Pedidos']],
  COCINA: [['/cocina', 'Panel de cocina'], ['/pedidos', 'Historial']],
};

export default function App() {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem('user') || 'null'));
  const nav = useNavigate();

  const login = (data) => {
    localStorage.setItem('token', data.token);
    localStorage.setItem('user', JSON.stringify(data.user));
    setUser(data.user);
    nav(MENU[data.user.rol][0][0]);
  };
  const logout = () => { localStorage.clear(); setUser(null); nav('/login'); };

  if (!user) return <Routes><Route path="*" element={<Login onLogin={login} />} /></Routes>;

  const rutas = MENU[user.rol];
  const guard = (path, el) => (rutas.some(([p]) => p === path) ? el : <Navigate to={rutas[0][0]} />);

  return (
    <>
      <nav className="navbar navbar-expand navbar-dark bg-dark px-3">
        <span className="navbar-brand">SIGPER</span>
        <div className="navbar-nav me-auto">
          {rutas.map(([p, t]) => <NavLink key={p} to={p} className="nav-link">{t}</NavLink>)}
        </div>
        <span className="text-light me-3">{user.nombre} ({user.rol})</span>
        <button className="btn btn-outline-light btn-sm" onClick={logout}>Cerrar sesión</button>
      </nav>
      <div className="container-fluid p-3">
        <Routes>
          <Route path="/usuarios" element={guard('/usuarios', <Users />)} />
          <Route path="/categorias" element={guard('/categorias', <Categories />)} />
          <Route path="/productos" element={guard('/productos', <Products />)} />
          <Route path="/nuevo" element={guard('/nuevo', <NewOrder />)} />
          <Route path="/cocina" element={guard('/cocina', <Kitchen />)} />
          <Route path="/pedidos" element={<Orders user={user} />} />
          <Route path="*" element={<Navigate to={rutas[0][0]} />} />
        </Routes>
      </div>
    </>
  );
}
