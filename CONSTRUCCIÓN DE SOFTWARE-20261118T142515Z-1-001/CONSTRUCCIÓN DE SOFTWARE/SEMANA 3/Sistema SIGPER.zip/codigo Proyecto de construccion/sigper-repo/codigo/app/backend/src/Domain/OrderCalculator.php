<?php
namespace Sigper\Domain;

use Sigper\Exceptions\ValidationException;

/** RF-15: valida líneas y calcula subtotales/total en centavos (evita errores de coma flotante). */
final class OrderCalculator
{
    /**
     * @param array $items    [['producto_id'=>1,'cantidad'=>2,'observaciones'=>'...'], ...]
     * @param array $products productos disponibles indexados por id (['id'=>..,'precio'=>..])
     * @return array{lines: array, total: float}
     */
    public function build(array $items, array $products): array
    {
        if ($items === []) {
            throw new ValidationException('El pedido debe tener al menos un producto');
        }
        $lines = [];
        $totalCents = 0;
        foreach ($items as $item) {
            $qty = $item['cantidad'] ?? null;
            if (!is_numeric($qty) || (int) $qty != $qty || (int) $qty <= 0) {
                throw new ValidationException('Las cantidades deben ser mayores que cero');
            }
            $qty = (int) $qty;
            $product = $products[(int) ($item['producto_id'] ?? 0)] ?? null;
            if ($product === null) {
                throw new ValidationException('Producto inexistente o no disponible');
            }
            $unit = (int) round(((float) $product['precio']) * 100);
            $totalCents += $unit * $qty;
            $note = trim((string) ($item['observaciones'] ?? ''));
            $lines[] = [
                'producto_id' => (int) $product['id'],
                'cantidad' => $qty,
                'precio_unitario' => $unit / 100.0,
                'subtotal' => ($unit * $qty) / 100.0,
                'observaciones' => $note !== '' ? $note : null,
            ];
        }
        return ['lines' => $lines, 'total' => $totalCents / 100.0];
    }
}
