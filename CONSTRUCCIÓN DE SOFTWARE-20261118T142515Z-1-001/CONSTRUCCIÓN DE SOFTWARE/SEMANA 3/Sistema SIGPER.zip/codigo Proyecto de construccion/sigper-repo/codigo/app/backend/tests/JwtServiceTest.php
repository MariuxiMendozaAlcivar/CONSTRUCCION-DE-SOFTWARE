<?php
namespace Sigper\Tests;

use InvalidArgumentException;
use PHPUnit\Framework\TestCase;
use Sigper\Exceptions\AuthenticationException;
use Sigper\Security\JwtService;

final class JwtServiceTest extends TestCase
{
    public function testEmiteYVerificaToken(): void
    {
        $jwt = new JwtService('secreto-de-prueba');
        $data = $jwt->verify($jwt->issue(['id' => 7, 'rol' => 'ADMIN']));
        $this->assertSame(7, $data['id']);
        $this->assertSame('ADMIN', $data['rol']);
    }

    public function testTokenManipuladoEsRechazado(): void
    {
        $jwt = new JwtService('secreto-de-prueba');
        [$h, $p, $s] = explode('.', $jwt->issue(['rol' => 'COCINA']));
        $falso = rtrim(strtr(base64_encode('{"rol":"ADMIN","exp":9999999999}'), '+/', '-_'), '=');
        $this->expectException(AuthenticationException::class);
        $jwt->verify("$h.$falso.$s");
    }

    public function testTokenExpiradoEsRechazado(): void
    {
        $jwt = new JwtService('secreto-de-prueba', 60);
        $token = $jwt->issue(['id' => 1], time() - 3600);
        $this->expectException(AuthenticationException::class);
        $jwt->verify($token);
    }

    public function testSecretoVacioNoSePermite(): void
    {
        $this->expectException(InvalidArgumentException::class);
        new JwtService('');
    }
}
