<?php
namespace Sigper\Tests;

use PHPUnit\Framework\TestCase;
use Sigper\Domain\{OrderCalculator, OrderStateMachine};
use Sigper\Exceptions\{ConflictException, ForbiddenException, NotFoundException, ValidationException};
use Sigper\Repositories\{OrderRepositoryInterface, ProductCatalogInterface};
use Sigper\Services\OrderService;

/** Pruebas de OrderService con repositorios falsos en memoria (sin base de datos). */
final class OrderServiceTest extends TestCase
{
    private FakeOrders $orders;
    private OrderService $service;
    private array $mesero = ['id' => 2, 'rol' => 'MESERO'];
    private array $cocina = ['id' => 3, 'rol' => 'COCINA'];

    protected function setUp(): void
    {
        $this->orders = new FakeOrders();
        $catalog = new FakeCatalog([1 => ['id' => 1, 'precio' => '2.50']]); // el producto 2 está inactivo
        $this->service = new OrderService($this->orders, $catalog, new OrderCalculator(), new OrderStateMachine());
    }

    private function nuevoPedido(): int
    {
        return $this->service->create($this->mesero, ['tipo' => 'MESA', 'mesa' => '5', 'items' => [['producto_id' => 1, 'cantidad' => 2]]]);
    }

    public function testCreaPedidoConTotalCalculado(): void
    {
        $id = $this->nuevoPedido();
        $this->assertSame(5.0, $this->orders->rows[$id]['total']);
        $this->assertSame('Pendiente', $this->orders->rows[$id]['estado']);
    }

    public function testPedidoPorMesaExigeNumeroDeMesa(): void
    {
        $this->expectException(ValidationException::class);
        $this->service->create($this->mesero, ['tipo' => 'MESA', 'items' => [['producto_id' => 1, 'cantidad' => 1]]]);
    }

    public function testPedidoParaLlevarNoRequiereMesa(): void
    {
        $id = $this->service->create($this->mesero, ['tipo' => 'LLEVAR', 'items' => [['producto_id' => 1, 'cantidad' => 1]]]);
        $this->assertNull($this->orders->rows[$id]['mesa']);
    }

    public function testNoPermiteProductoInactivo(): void
    {
        $this->expectException(ValidationException::class);
        $this->service->create($this->mesero, ['tipo' => 'LLEVAR', 'items' => [['producto_id' => 2, 'cantidad' => 1]]]);
    }

    public function testCocinaPuedeIniciarPreparacion(): void
    {
        $id = $this->nuevoPedido();
        $this->service->changeStatus($id, 'En preparación', $this->cocina);
        $this->assertSame('En preparación', $this->orders->rows[$id]['estado']);
    }

    public function testMeseroNoPuedeIniciarPreparacion(): void
    {
        $id = $this->nuevoPedido();
        $this->expectException(ForbiddenException::class);
        $this->service->changeStatus($id, 'En preparación', $this->mesero);
    }

    public function testNoSeModificaPedidoListo(): void
    {
        $id = $this->nuevoPedido();
        $this->orders->rows[$id]['estado'] = 'Listo';
        $this->expectException(ConflictException::class);
        $this->service->modify($id, ['items' => [['producto_id' => 1, 'cantidad' => 1]]]);
    }

    public function testPedidoInexistente(): void
    {
        $this->expectException(NotFoundException::class);
        $this->service->changeStatus(999, 'Listo', $this->cocina);
    }
}

final class FakeCatalog implements ProductCatalogInterface
{
    public function __construct(private array $products)
    {
    }

    public function findActiveByIds(array $ids): array
    {
        return array_intersect_key($this->products, array_flip($ids));
    }
}

final class FakeOrders implements OrderRepositoryInterface
{
    public array $rows = [];

    public function create(int $userId, string $tipo, ?string $mesa, array $lines, float $total): int
    {
        $id = count($this->rows) + 1;
        $this->rows[$id] = ['id' => $id, 'tipo' => $tipo, 'mesa' => $mesa, 'total' => $total, 'estado' => 'Pendiente'];
        return $id;
    }

    public function find(int $id): ?array { return $this->rows[$id] ?? null; }
    public function details(int $id): ?array { return $this->rows[$id] ?? null; }
    public function search(array $filters): array { return array_values($this->rows); }
    public function replaceItems(int $id, array $lines, float $total): void { $this->rows[$id]['total'] = $total; }
    public function updateStatus(int $id, string $from, string $to, int $userId): void { $this->rows[$id]['estado'] = $to; }
    public function summary(): array { return []; }
}
