<?php
namespace Sigper\Controllers;

use Sigper\Core\Request;
use Sigper\Core\Response;
use Sigper\Core\Validator;
use Sigper\Services\AuthService;

final class AuthController
{
    public function __construct(private AuthService $auth)
    {
    }

    public function login(Request $r): Response
    {
        Validator::required($r->body, ['identificador', 'password']);
        return Response::json($this->auth->login((string) $r->body['identificador'], (string) $r->body['password']));
    }

    public function me(Request $r): Response
    {
        return Response::json($r->user);
    }
}
