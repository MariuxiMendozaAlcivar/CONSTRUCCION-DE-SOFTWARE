<?php
namespace Sigper\Core;

use Sigper\Config\Env;
use Sigper\Exceptions\ValidationException;

final class Request
{
    /** Usuario autenticado (lo asigna AuthGuard). */
    public ?array $user = null;

    public function __construct(
        public readonly string $method,
        public readonly string $path,
        public readonly array $query,
        public readonly array $body,
        public readonly string $authorization = ''
    ) {
    }

    public static function fromGlobals(): self
    {
        $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $base = rtrim((string) Env::get('BASE_PATH', ''), '/');
        if ($base !== '' && strncmp($path, $base, strlen($base)) === 0) {
            $path = substr($path, strlen($base));
        }
        $raw = file_get_contents('php://input');
        $body = $raw ? json_decode($raw, true) : [];
        if (!is_array($body)) {
            throw new ValidationException('El cuerpo de la petición no es JSON válido');
        }
        $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
        return new self($_SERVER['REQUEST_METHOD'] ?? 'GET', rtrim($path, '/') ?: '/', $_GET, $body, $auth);
    }

    public function bearer(): string
    {
        return trim((string) preg_replace('/^Bearer\s+/i', '', $this->authorization));
    }
}
